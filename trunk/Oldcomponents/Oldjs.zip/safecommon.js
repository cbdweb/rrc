String.implement({
    /*
     Function: String.fmtmap
     Putpose:
     Take a given string, and apply a uppercase/lower case mapping.
     for example  "john".map("Aaaa") will turn "john" to "John"
     "john".map("AaaA") will turn "john" to "JohN"
     "john".map("Ax") will turn "john" to "John"
     Arguments:
     str - String.  defines the mini format map.
     */
    fmtmap: function(str){
        // this functionmaps a string to a format string.
        // for example  "john".map("Aaaa") will turn "john" to "John"
        // "john".map("AaaA") will turn "john" to "JohN"
        // "john".map("Ax") will turn "john" to "John"
        
        var result = '';
        for (var i = 0; i < str.length; i++) {
            var fmt = str.substr(i, 1);
            var nextchar = this.substr(i, 1);
            
            if (fmt === "A") {
                // maje this letter capital.
                result = result + nextchar.toUpperCase();
            }
            else 
                if (fmt === "a") {
                    // make this letter lowercare
                    result = result + nextchar.toLowerCase();
                }
                else 
                    if (fmt === "x") {
                        // give me everything else.
                        result = result + this.substr(i);
                    }
                    else 
                        if (fmt === "#") {
                            // just treat this as an integer
                            return ("" + parseInt(this, 10)); // treat this as a decvimal value.
                        }
        }
        return result;
    },
    /*
     Function:  String.left
     Purpose:
     Returns the n leftmost characters of the string.
     If less characters in this string, it gives all that are available.
     Arguments:
     n - int - the number of characters to return.
     */
    left: function(n){
        if (n <= 0) {
            return "";
        }
        else 
            if (n > this.length) {
                return this;
            }
            else {
                return this.substring(0, n);
            }
    },
    /*
     Function: String.right
     Purpose:
     Returns the n rightmost characters of the string.
     If less characters in this string, it gives all that are available.
     Arguments:
     n - int - the number of rightmost characters to return.
     */
    right: function(n){
        if (n <= 0) {
            return "";
        }
        else 
            if (n > this.length) {
                return this;
            }
            else {
                var iLen = this.length;
                return this.substring(iLen, iLen - n);
            }
    },
    /*
     Function: String.leftOf
     Purpose:
     Returns all of the characters to the left of the first occurance of the given string.
     If the given string is not present, it returns ""
     Arguments:
     str - return everything to the left of this string.
     */
    leftOf: function(str){
        var pos = this.indexOf(str);
        return pos <= 0 ? "" : this.left(pos);
    },
    /*
     Function: String.rightOf
     Purpose:
     Returns all of the characters to the right of the first occurance of the given string.
     If the given string is not present, it returns ""
     
     Arguments:
     str - return everything to the right of this string.
     
     */
    rightOf: function(str){
        var pos = this.indexOf(str);
        return (pos < 0) | (pos + str.length >= this.length) ? "" : this.substring(pos + str.length);
    },
    /*
     Function: String.leftOfLast
     Purpose:
     Returns all of the characters to the left of the last occurance of the given string.
     If the given string is not present, it returns ""
     Arguments:
     str - return everything to the left of the last orrurance of this string.
     */
    leftOfLast: function(str){
        var pos = this.lastIndexOf(str);
        return pos <= 0 ? "" : this.left(pos);
    },
    /*
     Function: String.rightOfLast
     
     Purpose:
     Returns all of the characters to the left of the last occurance of the given string.
     If the given string is not present, it returns ""
     
     Arguments:
     str - return everything to the left of the last orrurance of this string.
     */
    rightOfLast: function(str){
        var pos = this.lastIndexOf(str);
        return (pos < 0) | (pos + str.length >= this.length) ? "" : this.substring(pos + str.length);
    },
    /*
     oSubstitute
     Purpose :
     This function acts like the MooTools String.substitute.
     HOWEVER, it allows the processing of objects with sub objects.
     For example.
     var o={
     a: {aa:'abcd', ab : 'were'},
     b: {d:123, e : 'asd123'},
     c : 'whisper'
     };
     
     var s = " a.aa = {a.aa}, a.ab= {a.ab}, b.d = {b.d}, b.e = {b.e}, c = {c} ";
     var t = " aa = {aa}, ab= {ab}, b.d = {b.d}, b.e = {b.e}, c = {c} ";
     s.oSubstitute(o);
     gives " a.aa = abcd, a.ab= were, b.d = 123, b.e = asd123, c = whisper "
     t.oSubstitute(o.a);
     gives " aa = abcd, ab= were, b.d = , b.e = , c = "
     
     Arguments:
     object - Object- the source object that will be replaced.
     regexp - Regular expression to be evaluated to match the elements.
     */
    oSubstitute: function(object, regexp){
        return this.replace(regexp || (/\\?\{([^{}]+)\}/g), function(match, name){
            if (match.charAt(0) === "\\") {
                return match.slice(1);
            }
            var obj = object;
            if (name.indexOf('.') > -1) {
                // deal with names like a.b.c in case the object is nested.
                name = name.split('.');
                name.every(function(seg){
                    //if(obj){
                    if (obj[seg]) {
                        obj = obj[seg];
                        return true;
                    }
                    else {
                        obj = '';
                        return false;
                    }
                    //}
                });
                return (obj != undefined) ? obj : '';
            }
            return (object[name] != undefined) ? object[name] : '';
        });
    },
    basicNumber: function(){
        return this.replace(/[$%,]/g, '').toFloat();
    }
});

/*
 Object : mapControler
 
 Purpose:
 Handles all of the map functionality.
 Dosent concearn itself with any additional processing, just communication with the google maps API
 */
var mapController = {
    map: null,
    directionsDisplay: null,
    geocoder: null,
    directionsService: null,
    marker: null,
    oldEndpoints: {
        start: '',
        finish: '',
        waypoints: null,
        headwind: null,
        ridingstyle: null, // this is the value for relaxed.
        lastroute: null
    },
    
    /*
     Function: mapControler.initialize
     
     Purpose:
     Initialises the Google Map, and "finds" the current location.
     */
    initialize: function(){
        if (!display) {
            this.initTimeout = setTimeout(this.initialise, 500);
        }
        else {
            if (this.initTimeout) {
                clearTimeout(this.initTimeout);
                this.initTimeout = null;
            }
        }
        // this routine EXPECTS a div called map to exist.
        this.directionsService = new google.maps.DirectionsService();
        this.directionsDisplay = new google.maps.DirectionsRenderer({
            draggable: true
        });
        this.geocoder = new google.maps.Geocoder();
        this.goCurrentLocation();
        this.maxSegment = 250;
		this.graphsize = display.gerChartSize();
    },
    /*
     Function: mapControler.gpsBaseMap
     
     Purpose:
     Uses the GPS to locate the current position
     */
    gpsBaseMap: function(position){
        this.loadingMap = true;
        latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
        var myOptions = {
            center: latlng,
        };
        this.doBaseMap(myOptions);
    },
    /*
     Function: mapControler.ipBaseMap
     
     Purpose:
     Uses the ip address to "locate" the current position
     */
    ipBaseMap: function(){
        // If ClientLocation was filled in by the loader, use that info instead
        this.loadingMap = true;
        var latlng = new google.maps.LatLng(37.4419, -100.1419);
        if (google.loader.ClientLocation) {
            zoom = 13;
            latlng = new google.maps.LatLng(google.loader.ClientLocation.latitude, google.loader.ClientLocation.longitude);
            
        }
        var myOptions = {
            center: latlng,
        };
        
        this.doBaseMap(myOptions);
    },
    /*
     Function: mapControler.doBaseMap
     
     Purpose:
     the GPS and IP Basemap functions call this to draw the map, and
     locate the center point.
     */
    doBaseMap: function(myOptions){
        if (this.geocoder) {
            this.geocoder.geocode({
                'latLng': myOptions.center
            }, function(results, status){
                if (status == google.maps.GeocoderStatus.OK) {
                    // I REALY DONT WANT THIS HERE...
                    display.setStartAddress(results[0].formatted_address);
                }
            });
        }
        myOptions.streetViewControl = false;
        myOptions.zoom = 18;
        myOptions.mapTypeId = google.maps.MapTypeId.ROADMAP;
        // myoptions.mapTypeControl = false;
        myOptions.mapTypeControlOptions = {
            mapTypeIds: [google.maps.MapTypeId.ROADMAP, google.maps.MapTypeId.HYBRID],
            position: google.maps.ControlPosition.BOTTOM_RIGHT,
            style: google.maps.MapTypeControlStyle.DEFAULT
        };
        if (!this.map) {
            this.map = new google.maps.Map(document.getElementById("map"), myOptions);
            this.directionsDisplay.setMap(this.map); // woo hoo, draw that map.
        }
        else {
            this.map.setCenter(myOptions.center);
            this.directionsDisplay.setMap(null);
        }
    },
    /*
     Function: mapControler.goCurrentLocation
     
     Purpose:
     locates the map to the current location.
     Determines the best location service available, and uses that.
     */
    goCurrentLocation: function(){
        if (this.marker) {
            this.marker.setMap(null);
            delete this.marker;
        }
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(this.gpsBaseMap.bind(this), this.ipBaseMap.bind(this));
        }
        else {
            this.ipBaseMap();
        }
        if (!this.loadingMap) {
            this.ipBaseMap();
        }
        display.doDistanceBar(false, '');
    },
    
    goAddress: function(address, updateAddress){
    
        // this removes any routing already there.
        if (this.directionsDisplay) {
            this.directionsDisplay.setMap(null);
        }
        if (this.marker) {
            this.marker.setMap(null);
            delete this.marker;
        }
        
        this.geocoder.geocode({
            'address': address
        }, function(results, status){
            if (status == google.maps.GeocoderStatus.OK) {
                this.map.setCenter(results[0].geometry.location);
                this.marker = new google.maps.Marker({
                    map: this.map,
                    position: results[0].geometry.location,
                    draggable: true
                });
                this.markerEvent = google.maps.event.addListener(this.marker, 'dragend', function(event){
                    this.geocoder.geocode({
                        'latLng': event.latLng
                    }, function(results, status){
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[0]) {
                                if (updateAddress) {
                                    updateAddress(results[0].formatted_address);
                                }
                            }
                        }
                    });
                }
.bind(this));
                
            }
            else {
                alert("Geocode was not successful for the following reason: " + status);
            }
        }
.bind(this));
        display.doDistanceBar(false, '');
        
    },
    goRoute: function(start, finish, routetype, changedRoute){
    
        if (this.marker) {
            this.marker.setMap(null);
            delete this.marker;
        }
        var byMode = null;
        if (routetype == "car") {
            byMode = google.maps.DirectionsTravelMode.DRIVING;
        }
        else {
            byMode = google.maps.DirectionsTravelMode.WALKING;
        }
        
        
        
        var request = {
            origin: start,
            destination: finish,
            travelMode: byMode
        };
        
        // lets see if we've changed out start/end locations.
        if (this.oldEndpoints.start === start && this.oldEndpoints.finish === finish) {
            // this is the same path, although we might be traveling by car/bike now...
            if (this.oldEndpoints.waypoints) {
                request.waypoints = this.oldEndpoints.waypoints
            }
        }
        
        this.directionsService.route(request, (function(result, status){
            if (status == google.maps.DirectionsStatus.OK) {
                this.directionsDisplay.setDirections(result);
                
            }
        }).bind(this));
        // make sure that we can draw the route on the map.
        this.directionsDisplay.setMap(this.map);
        
        this.routeEvent = google.maps.event.addListener(this.directionsDisplay, 'directions_changed', function(){
            var directions = this.directionsDisplay.getDirections();
            // we're not doing waypoints in the traditional sence, so 
            // our start and finish points are in the 
            // directions.routes[0].legs[0].start_address   and
            // directions.routes[0].legs[0].end_address
            
            // lets see if we've changed out start/end locations.
            this.oldEndpoints.start = directions.routes[0].legs[0].start_address;
            this.oldEndpoints.finish = directions.routes[0].legs[0].end_address;
            // just recording the waypoints, breaks things, so lets do it different.
            // this.oldEndpoints.waypoints = directions.routes[0].legs[0].via_waypoint;
            var wps = directions.routes[0].legs[0].via_waypoint;
            if (wps && wps.length) {
                if (this.oldEndpoints.waypoints) {
                    this.oldEndpoints.waypoints.empty();
                }
                else {
                    this.oldEndpoints.waypoints = [];
                }
                
                wps.each(function(wp){
                    this.oldEndpoints.waypoints.push({
                        location: new google.maps.LatLng(wp.location.lat(), wp.location.lng()),
                        stopover: false
                    });
                }, this);
                
            }
            else {
                this.oldEndpoints.waypoints = null;
            }
            
            
            if (changedRoute) {
                changedRoute(directions.routes[0].legs[0].start_address, directions.routes[0].legs[0].end_address);
                display.doDistanceBar(true, "Trip distance : " + directions.routes[0].legs[0].distance.text);
                var simpleroute = this.calcPathSteps(directions.routes[0]);
                this.doRequest(simpleroute,directions.routes[0].legs[0].distance.value );
            }
            
        }
.bind(this));
        
    },
    calcPathSteps: function(route){
    
        var pts = {}; // this is the structure to see if we already have a pt.
        var order = []; // the order collection of points.
        // ok, now that we have waypoints, a trip is made up of routes...
        var lastpt = null;
        
        
        var mNo = 0;
        var routedist = 0;
        var droppedPt = false;
        var firstpt = true;
        var legdist = 0;
        var leghalfway = 0;
        var steps = route.legs[0].steps;
        steps.each(function(step, sindex){
            var latlngs = step.lat_lngs;
            latlngs.each(function(pt, index){
                if (sindex > 0) {
                    if (index == 0) {
                        // don't count the first point, cause it's the same as the last point of the one before
                        return;
                    }
                }
                
                var cpt = {
                    'lat': pt.lat(),
                    'lng': pt.lng()
                };
                var dist = this.latlngDist(lastpt, cpt);
                if (lastpt == null) {
                    lastpt = {};
                    lastpt.lat = cpt.lat + 1 - 1;
                    lastpt.lng = cpt.lng + 1 - 1;
                }
                
                var numsegments = Math.ceil(dist / this.maxSegment);
                
                var dff = 0;
                if (numsegments == 0) {
                    // to stop divide by zero...
                    numsegments = 1;
                    dff = 0;
                }
                var segdist = (dist / numsegments);
                var latdelta = (cpt.lat - lastpt.lat) / numsegments;
                var lngdelta = (cpt.lng - lastpt.lng) / numsegments;
                var tpt = {
                    'lat': lastpt.lat + 1 - 1,
                    'lng': lastpt.lng + 1 - 1
                };
                
                for (var i = 0; i < numsegments - dff; i++) {
                    lastpt.lat = tpt.lat + 1 - 1;
                    lastpt.lng = tpt.lng + 1 - 1;
                    tpt = {};
                    tpt.lat = lastpt.lat + latdelta;
                    tpt.lng = lastpt.lng + lngdelta;
                    // var ind = indexer.substitute( tpt );
                    // pts[ind] = true;
                    order.push(tpt);
                    lastpt.lat = tpt.lat + 1 - 1;
                    lastpt.lng = tpt.lng + 1 - 1;
                    
                }
            }, this);
        }, this);
        
        order.each(function(pt){
            pt.dist = this.latlngDist(lastpt, pt);
            lastpt = pt;
        }, this);
        return order;
    },
    
    /*
     Function: latlngDist( pt1, pt2 )
     calculate the distance betwen two latlng points.
     Parameters:
     pt1 - the first latlng point
     pt2 - the second latlng point
     Returns:
     The distance between the two points in meters.
     */
    latlngDist: function(pt1, pt2){
        // returns the distance in meters
        if (!pt1) {
            return 0;
        }
        var R = 6371; // km
        var dLat = (pt1.lat - pt2.lat).toRad();
        var dLon = (pt1.lng - pt2.lng).toRad();
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(pt1.lat.toRad()) * Math.cos(pt2.lat.toRad()) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c * 1000;
        return Math.ceil(d);
    },
    
    doRequest: function(steps, tripM){
		
		// make sure we have something to make a request from...
        var ridingstyle = $$('input[name=ridingStyle]:checked')[0].get('value');
        var headwind = ($('headwind').checked === true);
        
        var sameData = (this.oldEndpoints.ridingstyle === ridingstyle) && (this.oldEndpoints.headwind === headwind);
        
		if(steps){
			this.oldEndpoints.steps = steps;
			samedata = false;
		} else {
			steps = this.oldEndpoints.steps;
		}
		if(tripM){
			this.oldEndpoints.tripM = tripM;
			samedata = false;
		} else {
			tripM = this.oldEndpoints.tripM;
			
		}
		
        if (sameData) {
            // Not much to do here, move along.
			var battery = $$('input[name=batteryType]:checked')[0].get('value');
			if(battery != this.oldEndpoints.battery){
				this.oldEndpoints.battery = battery;
				this.calcCraphs();	
			} 
            return true;
        }
		
		// costruct the data object for the request.
		if(!steps){
			return;
		}
		var data = {};
		data.steps = steps;
        
        var doGetMethod = this.oldEndpoints.collected || false;
        
        var getArgs = "";
        if (doGetMethod) {
            if (headwind != lastRoute.headwind) {
                getArgs += '&headwind=' + headwind;
            }
            if (ridingstyle != lastRoute.ridingstyle) {
                getArgs += '&weight=' + ridingstyle; // yes, I know, but the servlet says weight for now.
            }
        }
        
        this.oldEndpoints.headwind = headwind;
        this.oldEndpoints.ridingstyle = ridingstyle;
        
        
        data.headwind = headwind;
        data.weight = ridingstyle;  // yes, the data that needs to go is marked as weight.  needs java refactoring.
        data.makecsv = false;		// we don't do that any more.
        data.xsize = this.graphsize.x;
		data.ysize = this.graphsize.y;
		data.tripm = tripM;
						// the length of the trip in meters.
        // make a request to the get service, to initialise the Session.
		/*
        var req = new Request.JSON({
            'url': '/RRC/routecalc',
            'noCache': true,
            'method': 'get',
            'async': false
        });
        req.send();
		*/
		var bCalcCraphs = this.calcCraphs.bind(this);
        var json = new Request.JSON({
            'url': '/RRC/routecalc',
            'data': {
                'route': JSON.encode(data)
            },
            'noCache': false,
            'onSuccess': bCalcCraphs
        });
        if (doGetMethod) {
            json.options.url = '/RRC/routecalc?action=json' + getArgs;
            json.options.method = 'get';
            json.options.data = '';
            
        }
        json.send();
		
        return false;
        // and that's it, out marker is now included in the waypoints.
    },
	calcCraphs : function( json, txt){
		var bigbattery = 200;
		var littlebattery = 100;
		
		if (!json) {
			json = this.oldEndpoints.json;
		}
		
		if (json) {
			this.oldEndpoints.json = json;
			// Ok, we've got a set of results, so lets process them.
			var energyUsed = 0;
			var travDist = 0;
			
			
			var bbExpiredPoint = -1;
			var bbExpiredLeg = "";
			
			var lbExpiredPoint = -1;
			var lbExpiredLeg = "";
			
			var forwardDist = []; // these are the values for the forward chart to be mapped against.
			var bForwardErg = []; // this is the forward energy useage for the BIG battery.
			var lForwardErg = []  // this is the forward energy useage for the LITTLE battery.
			
			var forwardDist = []; // these are the values for the forward chart to be mapped against.
			var bReverseErg = []; // this is the forward energy useage for the BIG battery.
			var lReverseErg = []  // this is the forward energy useage for the LITTLE battery.

			
			var lPerc = null;
			var bPerc = null;
			
			// find the max and min pts.
			var aMin = json.altmin;
			var aMax = json.altmax; // start at a TINY ammount, and it will get pulled up..
			
			
			var aDif = aMax - aMin;
			
			var mag = 1;
			var check = aDif / 10;
			while (check >= 10){
				// for every 10 we divide check by, we multiply mag by 10.
				check = check / 10;
				mag = mag * 10;
			}
			
			var altcutoff = ((aDif/mag)/4).round(0);			
			aMin = Math.round((aMin - mag )/mag) *mag;
			aMax = Math.round((aMax + mag )/mag) *mag;
			
			// ok, for my self curiosity.  after adjusting the range, lets see what dif we've got now.
			aDif = (aMax - aMin);
			altcutoff = aDif/30;  // this is +- 15% of the distance.
			 altcutoff = 0;
			
			if (aDif < 100) {
				if (aMin > 10) {
					aMax = aMin + 100;
				} else {
					aMin = 0;
					aMax = 100;
				}
			}
			
			// the first step distance is ALWAYS wrong.
			json.steps[0].dist=0;
			
			var lastsigalt = -99999;
			var keeppt = false;
			var alts = [];
			var xpoints = json.steps.length -1;  // this is the index we stop doing our triplet calcs.

			// pass 1, we look at the dDist values for 2 points, and this defines the value for our triplet.			
			json.steps.each( function(step, index){
				if (index > 0 && index < xpoints) {
					// the Java calculates a value called dDist which is the Sqrt(x^2 + y^2)
					// so, to figure out the "distance" in the triplet, we add the dDist with this point, and the next pt.
					step.kDist = step.dDist + json.steps[index+1].dDist; 
				}
			});
			
			
			 
			var sSteps = Array.clone(json.steps);
			var pointsToKeep = (215/3).round(0);  // cause I can.  (215 pixels / 4)

			// ok, now we sort these by their kDist value.
			// so that we can look at the most significant ones.
			// where the significant ones float to the start of the array.			
			sSteps.sort(function(a,b){
				return b.kDist - a.kDist;
			});
			
			sSteps.map( function( item, index) {
					item.keeppt = (index <= pointsToKeep);
			});
			
			// now we can re-sort this out, based on the tDist
			sSteps.sort(function(a,b){
				return a.tDist - b.tDist;
			});
			// keep the first and last points, always.
			sSteps[0].keeppt = true;
			sSteps.getLast().keeppt = true;
			
			var tdists = [];
			
			json.steps.each( function(step, index){
				keeppt = false;
				energyUsed += step.energy;
				travDist += step.dist;
			
				tdists.push(step.dist);
			
				/*
				if( step.alt > lastsigalt + altcutoff || step.alt < lastsigalt - altcutoff){
					keeppt = true;
					lastsigalt = step.alt;
					alts.push(step.alt);
					forwardDist.push(travDist);
				}
				
				*/
				if (sSteps[index].keeppt) {
					keeppt = true;
					// lastsigalt = step.alt;
					alts.push(step.alt);
					forwardDist.push(travDist);
				}
				if(energyUsed >= bigbattery){
					if( bbExpiredPoint == -1){
						bbExpiredPoint = index;
						bbExpiredLeg = "Forward";
						bPerc = (((bigbattery - energyUsed)/bigbattery) * 100).round(2);
						bPerc = bPerc > 0? bPerc : 0; 
						if( keeppt){
							bForwardErg.push(bPerc);	
						}
						
					}
					
				}else {
					bPerc = (((bigbattery - energyUsed)/bigbattery) * 100).round(2);
					bPerc = bPerc > 0? bPerc : 0; 
					if( keeppt){
						bForwardErg.push(bPerc);	
					}
				}
				if(energyUsed >= littlebattery){
					if (lbExpiredPoint == -1) {
						lbExpiredPoint = index;
						lbExpiredLeg = "Forward";
						lPerc = (((littlebattery - energyUsed)/littlebattery) * 100).round(2);
						lPerc = lPerc > 0? lPerc : 0;
						if (keeppt) {
							lForwardErg.push(lPerc);
						}
					}
					
				} else {
					lPerc = (((littlebattery - energyUsed)/littlebattery) * 100).round(2);
					lPerc = lPerc > 0? lPerc : 0;
					if (keeppt) {
						lForwardErg.push(lPerc);
					}
				}
				return ! ( bbExpiredPoint == -1 || lbExpiredPoint == -1);
			});
			
			// make sure to keep the first point too.
			lastsigalt = -99999;
			json.stepsreturn.each( function(step, index){
				energyUsed += step.energy;
				if( step.alt > lastsigalt + altcutoff || step.alt < lastsigalt - altcutoff){
					keeppt = true;
					lastsigalt = step.alt;
				}

				if(energyUsed >= bigbattery){
					if (bbExpiredPoint == -1) {
						bbExpiredPoint = json.stepsreturn.length - index - 1;
						bbExpiredLeg = "Return";
						bPerc = (((bigbattery - energyUsed)/bigbattery) * 100).round(2);
						bPerc = bPerc > 0? bPerc : 0; 
						if (keeppt) {
							bReverseErg.push(bPerc);
						}
					}
					
				} else {
					bPerc = (((bigbattery - energyUsed)/bigbattery) * 100).round(2);
					bPerc = bPerc > 0? bPerc : 0; 
					if (keeppt) {
						bReverseErg.push(bPerc);
					}
				}
				if(energyUsed >= littlebattery){
					if (lbExpiredPoint == -1) {
						lbExpiredPoint = json.stepsreturn.length - index - 1;
						lbExpiredLeg = "Return";
						lPerc = (((littlebattery - energyUsed)/littlebattery) * 100).round(2);
						lPerc = lPerc > 0? lPerc : 0;
						if (keeppt) {
							lReverseErg.push(lPerc);
						}
					}
					
				} else {
					lPerc = (((littlebattery - energyUsed)/littlebattery) * 100).round(2);
					lPerc = lPerc > 0? lPerc : 0;
					if (keeppt) {
						lReverseErg.push(lPerc);
					}
				}
				return ! ( bbExpiredPoint == -1 || lbExpiredPoint == -1);
			});
			
						
			// ok, we've got the max and min heights.  lets figure out the padding factor;.
			// start by figuring out the difference between the 2 .
			
			
			var tickDist = Math.round((100/(aMax / mag))*100)/100;
			
			var distance = (json.totdist < 1000? json.totdist : (json.totdist/1000).round(1))
			
			var chart = new GChart($('chart'),{
				// 'size': '300x350',   // this value gets set by the display, not by this code. 
				'encoding': 'e',					
				'tt': 'Trip Elevation and Battery Usage',
				'type': 'lxy',
				'xt': 'x,y,r,x',
				'f' : 'c,s,C3D9FF',
				// 'xl':'2:|Empty|100%25+Full|50%25+Full|3:|Distance+%28'+(json.totdist < 1000?'m':'Km' )+'%29',
				'xl':'2:|Empty|100%25+Full|50%25+Full|3:|Distance+%28'+(json.totdist < 1000?'m':'Km' )+'%29',
				'xp': '2,0,100,50|3,50',
				'xr': '0,0,'+distance+'|1,'+aMin+','+aMax,
				'xs' : '0,000000,10,1,lt,000000|1,000000,11.5,0.5,t,000000|2,000000,11.5,0.5,lt,000000|3,000000,11.5,0,l,000000',
				'co':'150B0B,00AE00',  ///,00AE00,FF9900,FF0000',
				'ds':'0,'+json.totdist+','+aMin+','+aMax,
				'g':'10,10,2,4',
				// 'ls':'0|3|3|3|3,6,2',
				'ls':'0|3',
				// 'ma':'|0,515',					
				// 'm':'f20Km+to+go+unassisted,FF0000,4,1,10,1|B,875406,0,0,0|fForward+trip,000000,1,5,10|fReturn+trip,000000,2,2,10|f80%25,000000,1,1000,10|fElevation+%28m%29,000000,0,0.5,10'
				'm' : 'B,875406,0,0,0'					
			});
			
			// add the altitude components.
			chart.addDataset(forwardDist, json.totdist );
			// chart.addDataset(tdists, 300);
			chart.addDataset(alts, aMax);
			
			// add the forward battery trip...
			chart.addDataset(forwardDist, json.totdist );
			chart.addDataset( bForwardErg , 100 );  // battery always starts out as 100%
			
			
			// now add the crazy other graphs...
			
			display.showGraph( chart );
			
			
		} else {
			alert('Sorry, there was an error calculatin the path.');
		}
	}
    
};


var IPhoneCheckboxes = new Class({

    //implements
    Implements: [Options],
    
    //options
    options: {
        checkedLabel: 'ON',
        uncheckedLabel: 'OFF',
        background: '#fff',
        containerClass: 'iPhoneCheckContainer',
        labelOnClass: 'iPhoneCheckLabelOn',
        labelOffClass: 'iPhoneCheckLabelOff',
        handleClass: 'iPhoneCheckHandle',
        handleBGClass: 'iPhoneCheckHandleBG',
        handleSliderClass: 'iPhoneCheckHandleSlider',
        elements: 'input[type=checkbox]'
    },
    
    //initialization
    initialize: function(options){
        //set options
        this.setOptions(options);
        //elements
        this.elements = $$(this.options.elements);
        //observe checkboxes
        this.elements.each(function(el){
            this.observe(el);
        }, this);
    },
    
    //a method that does whatever you want
    observe: function(el){
        //turn off opacity
        el.set('opacity', 0);
        //create wrapper div
        var wrap = new Element('div', {
            'class': this.options.containerClass
        }).inject(el.getParent());
        //inject this checkbox into it
        el.inject(wrap);
        //now create subsquent divs and labels
        var handle = new Element('div', {
            'class': this.options.handleClass
        }).inject(wrap);
        var handlebg = new Element('div', {
            'class': this.options.handleBGClass,
            'style': this.options.background
        }).inject(handle);
        var handleSlider = new Element('div', {
            'class': this.options.handleSliderClass
        }).inject(handle);
        var offLabel = new Element('label', {
            'class': this.options.labelOffClass,
            text: this.options.uncheckedLabel
        }).inject(wrap);
        var onLabel = new Element('label', {
            'class': this.options.labelOnClass,
            text: this.options.checkedLabel
        }).inject(wrap);
        var rightSide = wrap.getSize().x - 39;
        //fx instances
        el.offFx = new Fx.Tween(offLabel, {
            'property': 'opacity',
            'duration': 200
        });
        el.onFx = new Fx.Tween(onLabel, {
            'property': 'opacity',
            'duration': 200
        });
        //mouseup / event listening
        wrap.addEvent('mouseup', function(){
            var is_onstate = !el.checked; //originally 0
            var new_left = (is_onstate ? rightSide : 0);
            var bg_left = (is_onstate ? 34 : 0);
            //handlebg.hide();
			handlebg.setStyle('display' , 'none');
            new Fx.Tween(handle, {
                duration: 100,
                'property': 'left',
                onComplete: function(){
                    handlebg.setStyle('left', bg_left).setStyle('display' , 'block');;
                }
            }).start(new_left);
            //label animations
            if (is_onstate) {
                el.offFx.start(0);
                el.onFx.start(1);
            }
            else {
                el.offFx.start(1);
                el.onFx.start(0);
            }
            //set checked
            el.set('checked', is_onstate);
        });
        //initial load
        if (el.checked) {
            offLabel.set('opacity', 0);
            onLabel.set('opacity', 1);
            handle.setStyle('left', rightSide);
            handlebg.setStyle('left', 34);
        }
        else {
            onLabel.set('opacity', 0);
            handlebg.setStyle('left', 0);
        }
    },


});

/*
 Function: Number.prototype.toRad
 introduce teh roRad function to all numbers.
 Calculates this number from degrees to radians.  very useful
 when calculating distances.
 */
Number.prototype.toRad = function(){ // convert degrees to radians
    return this * Math.PI / 180;
};

window.addEvent('load', function(){
    mapController.initialize();
});
