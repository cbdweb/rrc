 // define the global values.
 
 var map; 					// The google map.
 var directionsDisplay;		// The directionsDisplay.
 var geocoder;				// The geocoder (for looking up names and addresses).
 var body;  // used to resize the screen...
 // to kick this all off, we call initialise.  however, wait til we have LOADED everything important...

// globals for storing/mapping routes.
var waypoints = [];
var markers = [];

// globals for breaking th path into smaller steps.
var lastRoute = null;
var maxSegment = 250;
var indexer = "lat={lat}&lng={lng}";
var simplePathData= null;
var geocoder = null;
var iconsize = null;
var anchor = null;
var origin = null;
var markerIcon = null;
var waypointIcon = null;
 
 var CHART_BASE_URL = 'http://chart.apis.google.com/chart';
 
 function initScreen() { 
 	setTimeout("window.scrollTo(0,1);",100); } 
	

 
 /*
   	Function: initialise
   		Start up the google map service, resize the screen, and figure out if we should be doing
   		"GPS" based start location, OR IP based location settings.
  */
 function initialize() {
 	body = $(document.body);
	directionsService = new google.maps.DirectionsService();
	directionsDisplay = new google.maps.DirectionsRenderer();
	geocoder = new google.maps.Geocoder();
	
	
	// Initialize default values
	iconsize = new google.maps.Size(11,11,'px', 'px');
	anchor = new google.maps.Point(0,0);
	origin = new google.maps.Point(6,6);
	// markerIcon = new google.maps.MarkerImage('imgs/marker.gif', iconsize, anchor, origin);
	markerIcon = new google.maps.MarkerImage('http://maps.gstatic.com/intl/en_au/mapfiles/dd-via.png', iconsize, anchor, origin);
	
	// waypointIcon = new google.maps.MarkerImage('imgs/waypoint.gif', iconsize, anchor, origin);
	waypointIcon = new google.maps.MarkerImage('http://maps.gstatic.com/intl/en_au/mapfiles/dd-via.png', iconsize, anchor, origin);

	// updateOrientation();
	
	sizeScreen();
	var doReq = doRequest.pass([false]);
	$$('input[name=start]').addEvent('change', changeWaypoint);
	$$('input[name=end]').addEvent('change', changeWaypoint);
	$('weight').addEvent('change', doReq);
	$$('input[name=headwind]').addEvent('change', doReq);
	$$('input[name=routetype]').addEvent('change', calcRoute);
	$$('input[name=batterytype]').addEvent('change', doBatteries);
	
	// add the event handlers for the buttons.
	$('btnRoute').addEvent('click', showDiv);
	$('btnProfile').addEvent('click', showDiv);
	$('btnUseage').addEvent('click', showDiv);
	$('btnEdit').addEvent('click', showEdit);
	$('btnDone').addEvent('click', hideEdit);
	
	// get the browser to support "Orientation" changes;
	var supportsOrientationChange = "onorientationchange" in window,
    	orientationEvent = supportsOrientationChange ? "orientationchange" : "resize";

	window.addEventListener(orientationEvent, function() {
		updateOrientation();
	}, false);
	
	if (!navigator.geolocation) {
		ipBaseMap();
			
	} else {
		// we've got geolocation awareness, so use the "current location"
		navigator.geolocation.getCurrentPosition( gpsBaseMap, ipBaseMap);
	}
	
	
	
  }
  
  window.addEvent('load', function(){
	hideURLBar();
	
});
  
  /*
   	Function: sizeScreen
   		Looks at the size of the active screen, and resizes the elements to make best use of the space.
   		Allows the same code to work on iphone. iphone4, and other mobile devices.
  */
  var contentsize = {};
  
  function sizeScreen(){
  	// fist things first, lets resize, to the sizeof the device.
	var windowSize = window.getSize();
	// only need to worry about "height"
	// these are the default portrait sizes.
	var headerSize = 44;
	var footerSize = 44;
	// header and footer change heights in landscape/portrait.
	if( body.hasClass("landscape")){
		headerSize = 30;
		footerSize = 30;
	}
	
	
	contentsize.x = windowSize.x - (4); // 4 pixels less than the full width.
	contentsize.y = windowSize.y - headerSize - footerSize;
	
	map_canvas = $('map_canvas');
	$('container').setStyle('height', contentsize.y );   // allow for header and footer.
	$('divRoute').setStyle('height', contentsize.y );   // allow for header and footer.
	$('divProfile').setStyle('height', contentsize.y );   // allow for header and footer.
	$('divUseage').setStyle('height', contentsize.y );   // allow for header and footer.
	$('map_canvas').setStyle('height', contentsize.y );   // allow for header and footer
	$('footer').setStyle('top', contentsize.y +  headerSize );   // allow for header
	$('battGraph').setStyle('height', contentsize.y - $('controlPanel').getSize.y -2 );   // allow for header and footer
  }
  
  
  /*
   	Function: updateOrientation
   		detets the "orientation" of the screen, and 
   		adjusts the portrait/landscape orientation applied by the CSS.
   		Also, tells google maps to "resize" the map.
  */
  function updateOrientation(){
	// This function changes the orientation.


	if (window.orientation) {
		switch (window.orientation) {
			case -90:
			case 90:
				body.addClass("landscape");
				body.removeClass("portrait");
				break;
			default:
				body.addClass("portrait");
				body.removeClass("landscape");
				break;
		}
	} else {
		if(screen.width){
			if( screen.width > screen.height){
				body.addClass("landscape");
				body.removeClass("portrait");
			} else {
				body.addClass("portrait");
				body.removeClass("landscape");
			}
		}
	}
	
	elevationData = null;
	batteryData = null;
	
	hideURLBar();
	sizeScreen();
	google.maps.event.trigger(map, 'resize');
	
	// redraw the graph...
	drawChart();
	dobatteries();
}

 /*
   	Function: hideURLBar
   		A function specific to the Iphone, to reclaim some screen 
   		real estate by hiding the URL bar.
   		
   		Has no effect on desktop browsers, or the (as far as I know)
  */
function hideURLBar(){
	setTimeout(function() {
		window.scrollTo(0, 1);

	}, 100);
	
}


 /*
   	Function: showDiv (e)
   		showDiv is an event handler. 
   		It will determine the button that's pressed, and
   		show the appropriate div (from route, profile, useage)
   		
   		Used by the Route, profile and Useage buttons.
   		
   	Parameters:
   		e - the event that was triggered.	
  */
function showDiv( e ){
	//  
	// .
	
	if( !$('ulRouteEdit').hasClass('hidden')) {
		return false;
	}
	
	var pressed = e.target;
	pressed = pressed.id.substr(3);
	
	var targetDiv = $('div'+pressed);
	
	// targetDiv.removeClass('hidden');
	showBtn(targetDiv);
	
	if( pressed == 'Route'){
		showBtn('btnEdit');
		hideBtn('btnDone');
	} else {
		hideBtn('btnEdit');
		hideBtn('btnDone');
		// this is the Profile and Useage sections, and we need an up to date version of the figures, so lets go get em...
		doRequest(false);
	}
	var divs = ['Route', 'Profile', 'Useage'];
	divs.erase(pressed);
	
	divs.each(function(name){
		// $('div'+name).addClass('hidden');
		hideBtn('div'+name );
	});
	
	
}

/*
   	Function: showBtn (id)
   		Shows a button with the id passed to it.
   	Parameters:
   		id - the id of the button to show
  */
function showBtn( id ){
	$(id).setStyle('display', 'block');
}

/*
   	Function: hideBtn (id)
   		hides a button with the id passed to it.
   	Parameters:
   		id - the id of the button to show
  */
function hideBtn( id ){
	$(id).setStyle('display', 'none');
}

/*
   	Function: showEdit
   		Shows the route edit "panel"
   		Shows the Done button, and removed the Edit button.
  */
function showEdit(){
	$('ulRouteEdit').removeClass('hidden');
	hideBtn('btnEdit');
	showBtn('btnDone');
}
/*
   	Function: hideEdit
   		Hides the route edit "panel"
   		Hides the Done button, and Shows the Edit button.
   		
   		Also, validates the addresses, and if valid, calculates teh route, 
   		and shows the profile and Useage buttons.
  */
function hideEdit(){
	$('ulRouteEdit').addClass('hidden');
	showBtn('btnEdit');
	hideBtn('btnDone');
	
	// do a quick validation check on the addresses...
	if( validateAddresses()){
	
		// this next line uses doRequest from routerise.js
		calcRoute();
	
		// ok, now that the route is calculated, we'll have details we can use to look at the profile.
		showBtn('btnProfile');
		showBtn('btnUseage');
	} else {
		hideBtn('btnProfile');
		hideBtn('btnUseage');
	}
}
/*
   	Function: validateAddresses
   		makes sure you have enterd something into the start and end 
   		addresses.
   		
   		If so, reeturns true,
   		Otherwise returns false.
   		
   	Returns:
   		true - there are addresses in both fields.
   		false - one or more addresses is empty.
  */
function validateAddresses(){
	var startAddress = $('waypoint_start').getElement('input');
	var endAddress = $('waypoint_end').getElement('input');
	
	if( startAddress.value !== ""  && endAddress.value !== "" ) {
		return true;
	}
	return false;
}

  
  /*
   	Function: gpsBaseMap(position)
   		our browser has geoLocation awareness. and so,
		we can put out current location to the point we are currently at.
	Parameters:
		position - the position the GPS has determined we are at.	
  */
  
  function gpsBaseMap(position){
	
	latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
	var myOptions = {
			zoom: 18,
			center: latlng,
			mapTypeId: google.maps.MapTypeId.ROADMAP
			
		};
	

	doBaseMap(myOptions);
}
  
  /*
   	Function: gpsBaseMap
   		Our browser dosent have geolocation awareness, but Google has a way of figuring out where 
   		we might be, based on our IP address.
  */
 
  function ipBaseMap(){
	// If ClientLocation was filled in by the loader, use that info instead
	var latlng = new google.maps.LatLng(37.4419, -100.1419);
	if (google.loader.ClientLocation) {
		zoom = 13;
		latlng = new google.maps.LatLng(google.loader.ClientLocation.latitude, google.loader.ClientLocation.longitude);

	}
	var myOptions = {
		zoom: zoom,
		center: latlng,
		mapTypeId: google.maps.MapTypeId.ROADMAP
		
	};
	doBaseMap(myOptions);
}

/*
   	Function: doBaseMap(myOptions)
   		Our browser has geoLocation awareness. and so,
		we can put out current location to the point we are currently at.
  */
function doBaseMap( myOptions ){
	
	if (geocoder) {
		geocoder.geocode({
			'latLng': myOptions.center
		}, function(results, status){
			if (status == google.maps.GeocoderStatus.OK) {
				// put the address into the From text field.
				var startField = $('wp_start');
				//if(startField.value == ''){
					startField.value = results[0].formatted_address;	
				//}
			}
		});
	}
	
	map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
	directionsDisplay.setMap(map);
	// put the draggable stuff back in here.. currently in the things_for_later.js
	// calcRoute();  // calcroute now checks to see if it has a route, and if not, dosen't do anything.
	// if we have addresses in the 2 fields to start, don't make them have to do
	// the edit, to see profile and useage.
	if( validateAddresses()){
		// this next line uses doRequest from routerise.js
		calcRoute();
	
		// ok, now that the route is calculated, we'll have details we can use to look at the profile.
		showBtn('btnProfile');
		showBtn('btnUseage');
	}
}


/*
   	Function: calcRoute
   		using the details we have in our start/end and sub locations,
   		get google to run us through out route, and draw it up for us.
  */
function calcRoute(){
	var travelType = $('routetype').checked ? google.maps.DirectionsTravelMode.WALKING : google.maps.DirectionsTravelMode.DRIVING;
//	var travelType = google.maps.DirectionsTravelMode.WALKING;
	//var start = '2 Anglia Crt, Werribee, VIC, 3030';
	//var end = '106 Flinders lane, Melbourne, VIC, 3000';
	var start = $('wp_start').get('value');
	var end = $('wp_end').get('value');
	var wps = [];
	// $('tripDistDisplay').addClass('vishid');	
	$('tripDist').set('text', 'Calculating...');
	
	if( start == "" || end == ""){
		// if either the start of the finish is blank, then just show that location.
		
		return false;
	}
		if(!waypoints.length){
		var wpd = $('subPoints');
			var existingwp = wpd.getElements('input[type=text]');
			
			
			existingwp.each( function(wp){
				var value = wp.get('value');
				if(value.trim() !==""){
					wps.push({'location':value, 'stopover' : true});
				}
			});
		} else {
		// ok, we have out waypoints array, so lets build up our wps list.
		waypoints.each( function(wp){
				wps.push({'location':(wp.cbdAddress||wp.getPosition()), 'stopover' : true});
		});
	}
	
	var request = {
			origin: start, 
			destination: end,
			travelMode: travelType,
			region : 'au'
	};
	
	if(wps.length){
		request.waypoints = wps;
	}
	
	directionsService.route(request, function(response, status) {
		if (status == google.maps.DirectionsStatus.OK) {
			directionsDisplay.setDirections(response);
			var route = response.routes[0];
			lastRoute = route;
			lastRoute.drawn = false;
			
			drawWaypointsHTML(route);
			
			var totalDist = 0;
			for (var i = 0; i < route.legs.length; i++) {
				totalDist += route.legs[i].distance.value;
			}
			$('tripDistDisplay').removeClass('vishid');	
			$('tripDist').set('text', (totalDist/1000).round(2) + ' Km' );
			if(totalDist < 300000){  // less than 300km
				simplePathData = {'steps':calcPathSteps( lastRoute )};
			} else {
				alert('Sorry, but this path is too long.  Please break your journey into smaller pieces.');
				return false;
			}

		}
	});
}    

/*
   	Function: getFormattedLocation
   		calculates the current address, from the google location service.
  */
function getFormattedLocation() {
	if (google.loader.ClientLocation.address.country_code == "US" &&
			google.loader.ClientLocation.address.region) {
		return google.loader.ClientLocation.address.city + ", " 
		+ google.loader.ClientLocation.address.region.toUpperCase();
	} else {
		return  google.loader.ClientLocation.address.city + ", "
		+ google.loader.ClientLocation.address.country_code;
	}
}

/*
   	Function: calcPathSteps( route )
   		calculates the path steps in the route.
   		creates the path steps we'll be passing to our service.
  */

function calcPathSteps( route ){
	
	// just so we dont keep doing thsi over and over, only do it once, if our route has changed.
	if (lastRoute.drawn){
		return true;
	}
	lastRoute.drawn = true;
	
	var pts =  {};		// this is the structure to see if we already have a pt.
	var order = []; // the order collection of points.
	// ok, now that we have waypoints, a trip is made up of routes...
	var lastpt = null;
	// clean out the waypoints.
	 clearMarkers();
	 waypoints.empty();
	var mNo = 0;
	var routedist = 0;
	var routehalfway = 0;
	var droppedPt = false;
	var firstpt = true;
	route.legs.each( function( leg, lindex ){
		legdist = 0;
		leghalfway = leg.distance.value /2;
		leghalfway = leghalfway - (leghalfway/10);
		
		droppedPt = false;
		var steps = leg.steps;
		steps.each( function( step, sindex ){
			var latlngs = step.lat_lngs;
			latlngs.each( function(pt, index){
				if(lindex > 0 || sindex > 0){
					if( index == 0){
						// don't count the first point, cause it's the same as the last point of the one before
						return;
					}
				}	

				var cpt = {'lat' : pt.lat(), 'lng' : pt.lng()};
				var dist = latlngDist(lastpt, cpt);
				if( lastpt == null){
					lastpt = {};
					lastpt.lat = cpt.lat + 1 - 1;
					lastpt.lng = cpt.lng + 1 - 1;
				}

				var numsegments = Math.ceil(dist/maxSegment);
				
				var dff = 0;
				if(numsegments == 0){
					// to stop divide by zero...
					numsegments = 1;
					dff = 0;
				}
				var segdist = (dist/numsegments);
				var latdelta = (cpt.lat - lastpt.lat)/numsegments;
				var lngdelta = (cpt.lng - lastpt.lng)/numsegments;
				var tpt = {'lat' : lastpt.lat + 1 - 1, 'lng' : lastpt.lng + 1 - 1};
				
				for(var i = 0; i < numsegments-dff; i++){
					lastpt.lat = tpt.lat + 1 - 1;
					lastpt.lng = tpt.lng + 1 - 1;
					tpt = {};
					tpt.lat = lastpt.lat + latdelta;
					tpt.lng = lastpt.lng + lngdelta;
					var ind = indexer.substitute( tpt );
					//if( !pts[ind] ){
						pts[ind] = true;
						order.push( tpt);
						// each time we add a point, we need to add a marker.
						legdist += segdist;
						//if(firstpt){
						//	addMarker(tpt, mNo);
						//	mNo ++;
						//	firstpt = false;
						//}
						if(!droppedPt  && legdist >= (leghalfway)){
							droppedPt = true;
							addMarker(tpt, mNo);
							mNo ++;
						}
					//}
					lastpt.lat = tpt.lat + 1 - 1;
					lastpt.lng = tpt.lng + 1 - 1;
					
				}
			});
		});
		// ok, at the end of each "route", we effectively have a waypoint.
		// so add the last pt to our waypoint list...
		// these points already have the path index in them, that we'll need for making waypoints.
		// ok, keep the last pt too.
		//addMarker(lastpt, mNo);
		//mNo ++;
		//firstpt = false;
		
		//markers[markers.length-1].cbdIsWaypoint = true;
		//markers[markers.length-1].setIcon(waypointIcon);
		//markers[markers.length-1].setTitle(leg.end_address);
		//markers[markers.length-1].cbdAddress = leg.end_address;
		//waypoints.push(markers[markers.length-1]);
	
	});
	// now that we've done ALL the points we need, we can add the first marker to our waypoints list.
	// see http://www.w3schools.com/jsref/jsref_splice.asp for description of splice.
	//markers[0].cbdIsWaypoint = true;
	//markers[0].setIcon(waypointIcon);
	//markers[0].cbdAddress = route.legs[0].start__address;
	//markers[0].setTitle(route.legs[0].start__address);
	//waypoints.splice(0, 0, markers[0] );
	// ok, now we have the order, I'm going to calculate the distances, even through we don't realy need to.
	var lastpt = null;
	order.each( function(pt){
		pt.dist = latlngDist(lastpt, pt);
		lastpt = pt;
	});
	
	// just to be sure we've got the right stuff, 
	
	
	// drawWaypointsHTML(  );
	
	
	return order;
}
/*
   	Function: Number.prototype.toRad
   	introduce teh roRad function to all numbers.
   		Calculates this number from degrees to radians.  very useful
   		when calculating distances.
 */
Number.prototype.toRad = function() {  // convert degrees to radians
	return this * Math.PI / 180;
};

/*
   	Function: latlngDist( pt1, pt2 )
	   	calculate the distance betwen two latlng points.
	Parameters:
		pt1 - the first latlng point
		pt2 - the second latlng point
	Returns:
		The distance between the two points in meters.
 */
function latlngDist( pt1, pt2 ) {
	// returns the distance in meters
	if(!pt1){
		return 0;
	}
	var R = 6371; // km
	var dLat = (pt1.lat - pt2.lat).toRad();
	var dLon = (pt1.lng-pt2.lng).toRad();
	var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
	Math.cos(pt1.lat.toRad()) * Math.cos(pt2.lat.toRad()) *
	Math.sin(dLon/2) * Math.sin(dLon/2); 
	var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
	var d = R * c * 1000;
	return Math.ceil(d);
}

/*
   	Function: addMarker(pt, markerno)
	   	draws a marker on the map, where we want our waypoints to go.
	Parameters:
		pt - the latlng point where the marker needs to go.
		markerno - an id for the marker point.
	Returns:
		The distance between the two points in meters.
 */
function addMarker(pt, markerno){

	var glatlng = new google.maps.LatLng(pt.lat,pt.lng);
	var marker = new google.maps.Marker({
	      position: glatlng, 
	      map: map, 
	      icon: markerIcon,
	      draggable : true,
	      flat : true,
	      clickable : true,
	      title : 'Drag to add a stop.'
	  }); 
	google.maps.event.addListener(marker, 'dragstart', function(){pickupMarker(marker);});
	google.maps.event.addListener(marker, 'drag', function(){moveMarker(marker);});
	// google.maps.event.addListener(marker, 'mouseup', function(event){dropMarker(event);});
	google.maps.event.addListener(marker, 'dragend', function(){dropMarker(marker);});
	marker.cbdPathIndex = markers.length;
	markers.push(marker);
	
}

var lastMoveTimer = 0;
function moveMarker(marker){
	if(marker){
		
		var latlng = marker.getPosition();
		// $('status').set('html', 'draged : '+latlng.lat() + ", " + latlng.lng() +" ->  " + marker.cbdPathIndex );
	} else {
		// $('status').set('html', 'draged');
	}
	// ok, re-work that path.
	/*
	var currentDate = new Date();
	var thisMoveTimer = currentDate.getTime();
	if( (thisMoveTimer - lastMoveTimer) > 1000){
		calcRoute(true);
		lastMoveTimer = thisMoveTimer;
	}
	*/
}

function dropMarker(marker){
	if(marker){
		var latlng = marker.getPosition();
		// $('status').set('html', 'drop : '+latlng.lat() + ", " + latlng.lng() +" ->  " + marker.cbdPathIndex );
	} else {
		// $('status').set('html', 'droped');
	}
	// ok, re-work that path.
	calcRoute();
}
function pickupMarker(marker){
	if(marker){
		var latlng = marker.getPosition();
		// $('status').set('html', 'picked up : '+latlng.lat() + ", " + latlng.lng() +" ->  " + marker.cbdPathIndex );
	} else {
		// $('status').set('html', 'picked up');
	}
	// here we need to add this point into the waypoints list.
	// using the cbdIsWaypoint and cbdPathIndex values stored in the marker, figure out where we need to add this waypoint in out list of waypoints.
	if(marker.cbdIsWaypoint){
		return true;
	}
	// ok, it's not yet a waypoint, so lets make it one.
	if(!waypoints.some( function(wp, index){
		if( index == 0){
			return false;
		}
		var pwp = waypoints[index -1];
		if( (pwp.cbdPathIndex < marker.cbdPathIndex) &&  (marker.cbdPathIndex < wp.cbdPathIndex) ){
			// if out marker is between two existing waypoints, then we need to add out marker in here.
			waypoints.splice(index, 0, marker);
			marker.cbdIsWaypoint = true;
			marker.setIcon(waypointIcon);
			return true;
		}
		return false;
	}) ) {
		// ok, it didn't get added, so push it in buddy.
		waypoints.push(marker);
	}

	// and that's it, out marker is now included in the waypoints.
}

function addWayPoint(id){
	// ok, here's the plan.
	// When they hit AddWaypoint, we add a new input at the bottom of $('waypoints').
	// we then get the location in the End input field, and copy it to the new input
	// and then we blank out the end point.
	/*
	var existingWP = wpd.getChildren('div');
	// dont let them keep adding blank ones.  they will have to enter in a value.
	if( existingWP.length){
		var lastwp = existingWP[existingWP.length-1];
		var inp = lastwp.getElement('input');
		if(inp.value == ""){
			return;
		}
	}
	*/
	var wpd = $('subPoints');
	var prevWP = $(id);
	// waypoints.splice(idNo, 0, null);
	
	drawWPHTML(wpd, prevWP, "");
	// calcRoute();
}

function drawWaypointsHTML( route ){

		var wpd = $('subPoints');
		// var newDiv = new Element('div');
		if(!route){
			return;
		}
		wpd.empty();
		
		route.legs.each( function( leg, index ){
			// each route starts with its own waypoint.
			if( index == 0 ){
				// set the first waypoint...
				// var wp0 = $('waypoint_0').getElement('input');
				// wp0.set('value',route.start_geocode.formatted_address);
			} else {
				drawWPHTML(wpd, index, leg.start_address  );
			}
		});
		// now add the end point.
				
		//var lastRoute = trip.routes[ trip.routes.length-1];
		//var wpEnd = $('waypoint_end').getElement('div');
		//var wpEndInput = $('waypoint_end').getElement('input');
		//wpEnd.set('id', 'waypoint_'+ trip.routes.length);
		//wpEndInput.set('id', 'wp_'+ trip.routes.length);
		
		//wpEndInput.set('value',lastRoute.end_geocode.formatted_address);
		// drawWPHTML(wpd, trip.routes.length, lastRoute.end_geocode.formatted_address , true );

}

function drawWPHTML(wpd, index, address, ending  ){
	// draw a single new waypoint.  used in a few places.
	
	var prevWP = null;
	if(typeof( index) == "object"){
		prevWP = index;
		index = 9999;
	}
	
	// '&nbsp;<a href="#" title="Remove Waypoint." class="removeWaypoint" >'+
	// '<img src="imgs/remove.gif" alt="Remove Waypoint" /></a>'+
	// '&nbsp;<a href="" title="Add Waypoint." class="addWaypoint">'+
	// '<img src="imgs/add.gif" alt="Add waypoint."/></a>'
	
	var newWaypoint = new Element('div', {
		'html' : '<input type="text" id="wp_'+index+'"/>',
		'id' : 'waypoint_'+ index,
		'class': 'hidden'
	});
	if( index ===0 || ending ){
		newWaypoint.removeClass('hidden');
	}
	// get rid of the last addWaypoint icon...
	if(prevWP){
		newWaypoint.inject(prevWP, 'after');
	} else {
		newWaypoint.inject(wpd, 'bottom');	
	}
	
	var wpinput = newWaypoint.getElement('input');
	wpinput.set('value', address);
	/*wpinput.addEvent('change', changeWaypoint);
	if(ending){
		var plus = newWaypoint.getElement('a.addWaypoint');
		if(plus){
			plus.addClass('hidden');
		}
	} */
}

var chart = {
	alts : null
};

var elevationData = null;
var batteryData = null;

function drawChart(  ){
	if (! chart.alts){
		return false;
	}
	if(elevationData){
		// we've already drawn this, so don't draw again.
		return true;
	}
	
	var eGraph = $('eGraph');
	var height = contentsize.y ;   // allow for header and footer
	var width = contentsize.x;
	height -= $('profile_panel').getSize().y;
	 
	var size = {};
	// var size = $('profile_panel').getSize().y;
	size.y = height;
	size.x = width - 20;
	
	if (size.x > 1000) {
		size.x = 1000;
	}
	size.x -= 20;
	if (size.y > 300) {
		size.y = 300;
	}
	
	$('eGraph').src="pleasewait.html";	 
	$('eGraph').setStyle('width', size.x);
	$('eGraph').setStyle('height', size.y);
	
	// size.x = 1000;
	// size.y = 300;
	
	
	// find the max and min pts.
	var aMin = 999999;
	var aMax = -999999;
	
	chart.alts.each( function(a){
		if(a<aMin){
			aMin = a;
		}
		if(a > aMax){
			aMax = a;
		}
	});
	
	// ok, we've got the max and min heights.  lets figure out the padding factor;.
	// start by figuring out teh diference between the 2 .
	var aDif = aMax - aMin;
	
	var mag = 1;
	var check = aDif / 10;
	while (check > 1){
		// for every 10 we divide check by, we multiply mag by 10.
		check = check / 10;
		mag = mag * 10;
	}
	
	aMin = Math.round((aMin - mag )/mag) *mag;
	aMax = Math.round((aMax + mag )/mag) *mag;
	
	var tickDist = Math.round((100/(aMax / mag))*100)/100;  // not sure if we need this, but hang onto it, just in case...
	
	// alert(size.x+'x'+size.y);
	var expiryPts = "";
	
	if( chart.bbExpiredPoint > -1 ){
//		expiryPts += 'ABig Battery expires on '+chart.bbExpiredLeg+' trip,FF0000,0,'+chart.bbExpiredPoint+',15|o,FF0000,0,'+chart.bbExpiredPoint+',10';
		expiryPts += 'ABig Battery expires on '+chart.bbExpiredLeg+' trip,0000FF,0,'+chart.bbExpiredPoint+',15|o,0000FF,0,'+chart.bbExpiredPoint+',10';
	}
	
	if( chart.lbExpiredPoint > -1 ){
		if(expiryPts !== ""){
			expiryPts += "|";	
		}
		// expiryPts += 'ALittle Battery expires on '+chart.lbExpiredLeg+' trip,FF0000,0,'+chart.lbExpiredPoint+',15|o,FF0000,0,'+chart.lbExpiredPoint+',10';
		expiryPts += 'fLittle Battery expires on '+chart.lbExpiredLeg+' trip,FF0000,0,'+chart.lbExpiredPoint+',15|o,FF0000,0,'+chart.lbExpiredPoint+',10';
	}
	
	

	
	
	 
	
	lastBattery = $('batterytype').checked;
	
	var bPath = "";
	var chls = "";
	var chco = "";
	var chds = "";
	
	bPath += chart.ForwardDist.join(',')+'|'+chart.alts.join(','),
	chls += '2';
	chco += '009900';
	chds += '0,' + chart.totDist + ','+aMin+','+aMax;
	
	if ($('batterytype').checked) {
		bPath += "|"+chart.ForwardDist.slice(0, chart.bForwardErg.length - 1).join(',') + '|' + chart.bForwardErg.join(',');
		chls += ',2';
		chco += ',0000FF';
		chds += ',0,' + chart.totDist + ',0,101';
		
		if (chart.bReverseErg.length > 0) {
			bPath += '|' + chart.ForwardDist.reverse().slice(0, chart.bReverseErg.length - 1).join(',') + '|' + chart.bReverseErg.join(',');
			chls += '|2';
			chco += ',0000FF';
			chds += ',0,' + chart.totDist + ',0,101';
			chart.ForwardDist.reverse()
		}
		
	}
	else {
	
		bPath = chart.ForwardDist.slice(0, chart.lForwardErg.length - 1).join(',') + '|' + chart.lForwardErg.join(',');
		chls += ',2';
		chco += ',FF0000';
		chds += ',0,' + chart.totDist + ',0,101';
		
		
		if (chart.lReverseErg.length > 0) {
			bPath += '|' + chart.ForwardDist.reverse().slice(0, chart.lReverseErg.length - 1).join(',') + '|' + chart.lReverseErg.join(',');
			chls += '|2';
			chco += ',FF0000';
			chds += ',0,' + chart.totDist + ',0,101';
			chart.ForwardDist.reverse()
		}
	}	
	


	elevationData = $H({
		'cht' : 'lxy',  // was lc
		'chs' : size.x+'x'+size.y,
		'chtt' : 'Elevation',
		'chls' : chls,
		'chco' : chco,
		'chds'	: chds,
		'chxt' : 'x,x,y,y',
		'chxl'	: '1:|Kms|3:|Percent',
		'chxp' : '1,50|3,50',
		'chxs' : '0,676767,11.5,0,lt,676767|1,676767,11.5,0,lt,676767|2,676767,11.5,0,lt,676767|3,676767,11.5,0,lt,676767',
		'chxr'	: '0,0,'+chart.kmDist+'|2,0,100',
		'chd' : 't:'+bPath,
		'chg' : '3,10,2,6'   // the 3 at the start needs to be figured out.  it's the x distance.
	});
	
/*
	elevationData = $H({
		'cht' 	: 'lxy',  // was lc
		'chs' 	:  size.x+'x'+size.y,
		'chtt'	: 'Elevation in Meters',
		'chls'	: '2',
		'chco'	: '006600',
		'chds'	: '0,'+chart.totDist+','+aMin+','+aMax,
		'chxt'	: 'x,x,y,y',
		'chxp' 	: '1,50|3,50',
		'chxl'	: '1:|Kms|3:|Altitude',
		'chxp'	: '1,50|3,50',
		'chxs'	: '0,676767,11.5,0,lt,676767|1,676767,11.5,0,lt,676767',
		'chxr'	: '0,0,'+chart.kmDist+'|1,0,100|2,'+aMin+','+aMax +'|3,0,100',
		
		'chm' 	: 'B,C5D4B5BB,0,0,0',
		'chg'	: '3,'+tickDist+',2,6'   // the 3 at the start needs to be figured out.  it's the x distance.
	});
*/
	//if(expiryPts  !== ""){
	//	elevationData.set('chm' , 'B,C5D4B5BB,0,0,0'+ "|"+expiryPts);	
	//}
	
	$('eGraph').src="chartloader.html?elevation";	 
	 $('eGraph').setStyle('width', size.x);
	 $('eGraph').setStyle('height', size.y);
	// eGraph.setStyle('background-image', 'url('+cURL+')' );

}


/*
   	Function: elevationIframe()
	   	When the iframe loads, it grabs the data from charts, and then 
	   	calls the chart drawing tools to draw the chart.
	
	Returns:
		Nothing.  submits the form, and gets the new chart.
		
 */
function elevationIframe(){
	
	// get the document from the egraph iframe.
	var form = $($('eGraph').contentDocument.forms[0]);
	//  $('eGraph').set('src', cURL);
	 elevationData.each(function(item, label){
	 	var fld = form.getElementById(label);
		fld.value = item;
	 });
	 var fields = form.getElements('input');
	 fields.each( function(item){
	 	if(item.value == ""){
			item.dispose();
		}
	 });
	 form.submit();
	 
}

function batteryIframe(){
	
	// get the document from the egraph iframe.
	var form = $($('eBatt').contentDocument.forms[0]);
	 batteryData.each(function(item, label){
	 	var fld = form.getElementById(label);
		fld.value = item;
	 });
	 var fields = form.getElements('input');
	 fields.each( function(item){
	 	if(item.value == ""){
			item.dispose();
		}
	 });
	 form.submit();
	
}

var lastWeight = null;
var lastHeadwind = null;

function doRequest(csv){
	if(!lastRoute){
		return false;
	}
	var weight = $('weight').get('value').toInt();
	var headwind = ($('headwind').checked == true);
	
	var sameData = (lastWeight == weight ) || (lastHeadwind == headwind); 
	
	if(elevationData && batteryData && sameData){
		// if we have elevation and battery datat, then we don't need to do much, just let the system switch the div's
		return true;
	}
	// clear out the last status messages...
	var summaryPanel = $('status');
	// summaryPanel.innerHTML = "";
	
	
	
	if(weight == 0){
		alert('Please select the weight of you and your bike and try again.');
		return false;
	}
	
	
	// summaryPanel.innerHTML +="<div id=\"progressarea\"><div id=\"progress\"></div><div style=\"border:1px solid #000; width:200px;\"><div id=\"progressbar\" style=\"width:1px;background:#000;\">&nbsp;</div></div></div>";
	
	var doGetMethod = lastRoute.collected || false;
	var disableThese = ['input', 'a', 'select'];
	var controlPanel = $('controlPanel');
	
	// var data = {'steps':calcPathSteps( lastRoute )};
	var data = simplePathData;
	
	var getArgs = "";
	if(doGetMethod){
		if(headwind != lastRoute.headwind){
			getArgs += '&headwind=' + headwind;
		}
		if(weight != lastRoute.weight){
			getArgs += '&weight=' + weight;
		}
	}
	
	lastRoute.headwind = headwind;
	lastRoute.weight = weight;
	
	
	data.headwind=headwind;
	data.weight=weight;
	data.makecsv=csv;

	// make a request to the get service, to initialise the Session.
	var req = new Request({
		'url' : '/RRC/routecalc',
		'noCache' : true,
		'method' : 'get',
		'async' : false
	});
	req.send();
	
	disableThese.each(function(elementtypes){
		var elements = controlPanel.getElements(elementtypes);
		elements.set('disabled', true);
		if(elementtypes=="a" ){
			elements.setStyle('display', 'none');
		}
	});
	var timedrequest = null;
	if(data.makecsv){
		// make an iframe, create a form, create a field, called data, with the json string in it. then submit the form to the servlet.
		// we should then be asked to save the file.... maybe.
		// the child document will get it's data value from this pages data field.
		
		
		var ifloader = $('iframeloader');
		ifloader.empty();
		
		// Ok, if we havent yet go this path, then we need to do the "post" approace,
		// otherwise, we can use the get approach.
		var iframeURL = doGetMethod ? '/RRC/routecalc?action=csv'+getArgs : 'getcsv.html';
		
		
		var iframe = new Element("iframe",{
			'src' : iframeURL
		});

		//var ifcontent = $(iframe.contentDocument.body);
		//var dfield = ifcontent.getElement('data');
		if( !doGetMethod){
			// becasue we're doing the post method, add the data field.
			var	 dfield = new Element("input",{
				'name' : 'data',
				'id' : 'data',
				'value' : JSON.encode(data) 
			});

			dfield.inject(ifloader,'bottom');
		}
		iframe.inject(ifloader,'bottom');
		// dfield.set('value', '{ "route" : '+JSON.encode(data) +'}');
	} else {
		
		var json = new Request.JSON({
			'url' : '/RRC/routecalc',
			'data' : { 'route' : JSON.encode(data) },
			'noCache' : false,
			'onSuccess' : function(json, txt){
				var results = $('battery');
				var bigbattery = 200;
				var littlebattery = 100;


				if(json){
					chart.alts = json.alts;
					chart.totDist = json.totdist;
					// using the charts spec...
					// chd=t:<line_1_x1>,<line_1_x2>,...|<line_1_y1>,<line_1_y2>,...|
      				//       <line_2_x1>,<line_2_x2>,...|<line_2_y1>,<line_2_y2>,...
					
					chart.ForwardDist = [];
					chart.bForwardErg = [];
					chart.lForwardErg = [];
					chart.bReverseErg = [];
					chart.lReverseErg = [];
					// now we/ve got to process the energy, and figure out where it all gets used up.
					var energyUsed = 0;
					var travDist = 0;
					
					
					var bbExpiredPoint = -1;
					var bbExpiredLeg = "";
					
					var lbExpiredPoint = -1;
					var lbExpiredLeg = "";
					
					elevationData = null;
					batteryData = null;
					
					json.steps.each( function(step, index){
						energyUsed += step.energy;
						travDist += step.dist;
						chart.ForwardDist.push(''+travDist);
						
						if(energyUsed >= bigbattery){
							if( bbExpiredPoint == -1){
								bbExpiredPoint = index;
								bbExpiredLeg = "Forward";
								var bPerc = (((bigbattery - energyUsed)/bigbattery) * 100).round(2);
								bPerc = bPerc > 0? bPerc : 0; 
								chart.bForwardErg.push(''+bPerc);
							}
							
						}else {
							var bPerc = (((bigbattery - energyUsed)/bigbattery) * 100).round(2);
							bPerc = bPerc > 0? bPerc : 0; 
							chart.bForwardErg.push(''+bPerc);
						}
						if(energyUsed >= littlebattery){
							if (lbExpiredPoint == -1) {
								lbExpiredPoint = index;
								lbExpiredLeg = "Forward";
								var lPerc = (((littlebattery - energyUsed)/littlebattery) * 100).round(2);
								lPerc = lPerc > 0? lPerc : 0;
								chart.lForwardErg.push(''+lPerc);
							}
							
						} else {
							var lPerc = (((littlebattery - energyUsed)/littlebattery) * 100).round(2);
							lPerc = lPerc > 0? lPerc : 0;
							chart.lForwardErg.push(''+lPerc);
						}
						return ! ( bbExpiredPoint == -1 || lbExpiredPoint == -1);
					});
					
					json.stepsreturn.each( function(step, index){
						energyUsed += step.energy;

						if(energyUsed >= bigbattery){
							if (bbExpiredPoint == -1) {
								bbExpiredPoint = json.stepsreturn.length - index - 1;
								bbExpiredLeg = "Return";
								var bPerc = (((bigbattery - energyUsed)/bigbattery) * 100).round(2);
								bPerc = bPerc > 0? bPerc : 0; 
								chart.bReverseErg.push(''+bPerc);
							}
							
						} else {
							var bPerc = (((bigbattery - energyUsed)/bigbattery) * 100).round(2);
							bPerc = bPerc > 0? bPerc : 0; 
							chart.bReverseErg.push(''+bPerc);
						}
						if(energyUsed >= littlebattery){
							if (lbExpiredPoint == -1) {
								lbExpiredPoint = json.stepsreturn.length - index - 1;
								lbExpiredLeg = "Return";
								var lPerc = (((littlebattery - energyUsed)/littlebattery) * 100).round(2);
								lPerc = lPerc > 0? lPerc : 0;
								chart.lReverseErg.push(''+lPerc);
							}
							
						} else {
							var lPerc = (((littlebattery - energyUsed)/littlebattery) * 100).round(2);
							lPerc = lPerc > 0? lPerc : 0;
							chart.lReverseErg.push(''+lPerc);
						}
						return ! ( bbExpiredPoint == -1 || lbExpiredPoint == -1);
					});
					
					chart.bbExpiredPoint = bbExpiredPoint;
					chart.bbExpiredLeg = bbExpiredLeg;
					chart.lbExpiredPoint = lbExpiredPoint;
					chart.lbExpiredLeg = lbExpiredLeg;
					chart.kmDist = (json.totdist/1000).round(2);
					
					drawChart();
					var lb = battPercent(json.totenergy.round(2) ,littlebattery);
					var lb2 = battPercent(json.totenergyRet.round(2) ,littlebattery);
					var bb = battPercent(json.totenergy.round(2) ,bigbattery);
					var bb2 = battPercent(json.totenergyRet.round(2) ,bigbattery);
					lastBattery = {
						'lb' : lb,
						'lb2' : lb2,
						'bb' : bb,
						'bb2' : bb2
					};
					
			
					doBatteries();			
			
					lastRoute.collected = true;
					
				} else {
					alert('Sorry, there was an error calculatin the path.');
				}
				// clean up the timed request...
				if(timedrequest){
					var results = $('progress');
					var bar = $('progressbar');
					// results.set('html', 'Completed.');
					// bar.setStyle('width', 200);
					timedrequest.stopTimer();
					disableThese.each(function(elementtypes){
						var elements = controlPanel.getElements(elementtypes);
						elements.set('disabled', false);
						if(elementtypes=="a" ){
							elements.setStyle('display', '');
						}
					});
				}
			}
		});

		
		
		if(doGetMethod){
			json.options.url = '/RRC/routecalc?action=json'+getArgs;
			json.options.method = 'get';
			json.options.data = '';
			
		}
		json.send();


		
	}
	timedrequest= new Request.JSON({
	    method: 'get',
	    'url' : '/RRC/routecalc',
		'noCache' : true,
		'onSuccess' : function(json, txt){
			
			//var results = $('progress');
			//var bar = $('progressbar');
			if(json){
				if(json.status=="Calculating" || json.status=="Collected"){
					var comp = Math.ceil(json.count / json.size *100);
					if( comp < 100){
						// draw the in progress bar.
						//results.set('html' , json.status + ' : ' + json.count + ' of ' + json.size + '('+comp+'%)');
						//bar.setStyle('width', comp * 2);
					} else {
						// results.set('html', 'Completed.');
						// bar.setStyle('width', 200);
						timedrequest.stopTimer();
						lastRoute.collected = true;
						disableThese.each(function(elementtypes){
							var elements = controlPanel.getElements(elementtypes);
							elements.set('disabled', false);
							if(elementtypes=="a" ){
								elements.setStyle('display', '');
							}
						});
					}
				} else {
					// results.set('html' , json.status);
					// bar.setStyle('width', 0);	
				}
			} else {
				// results.set('html' , txt);
				// bar.setStyle('width', 0);
			}
			
		},
	    initialDelay: 1000, 
	    delay: 1000,
	    limit: 15000
	}).startTimer();
	// timedrequest.send();
	return false;
	// and that's it, out marker is now included in the waypoints.
}


function changeWaypoint(event){
	var inp = event.target;
	//var parentdiv = inp.getParent('div');
	var parentdiv = inp.getParent();
	var theID = parentdiv.get('id');
	var tail = theID.replace('waypoint_', '');
	var idNo = tail.toInt();
	if (inp.value){
		geocoder.geocode( { 'address': inp.value}, function(results, status) {
		        if (status == google.maps.GeocoderStatus.OK) {
					if( !isNaN( idNo ) ){
						// idNo will ne Nan, if the start and end fields are 
						// used as our source.
				          var marker = new google.maps.Marker({
				              map: map, 
				              position: results[0].geometry.location,
				              icon : waypointIcon
				          });
				          marker.cbdAddress = inp.value; 
				          // we've already got this waypoint, so just update it.
				          if(waypoints[idNo]){
				  			waypoints[idNo].setMap(null);  // remove this waypoint, cause we're making a new one.
				  		    waypoints[idNo] = marker;	
				  			} else {
				  			// ok, this waypoint ISNT here, so add it to the "end" of the waypoints.
				  			waypoints.push( marker );
	   
				  		  }
					 } 
			         calcRoute();
		        } else {
		        	alert("Geocode was not successful for the following reason: " + status);
		        }
		});
		
	}

}
var lastBattery = null;
function doBatteries(){
	/* if ($('batterytype').checked) {
	 showBattery('to', lastBattery.bb.chunk);
	 showBattery('ret', lastBattery.bb2.chunk);
	 } else {
	 showBattery('to', lastBattery.lb.chunk);
	 showBattery('ret', lastBattery.lb2.chunk);
	 } */
	
	
	
	
	var width = contentsize.x;
	
	var size = {};
	size.x = width;
	
	// var size = $('divUseage').getSize();
	var height = contentsize.y -  $('controlPanel').getSize().y -2 ;
	
	size.y = height;
	if (size.x > 1000) {
		size.x = 1000;
	}
	size.x -= 20;
	
	if (size.y > 300) {
		size.y = 300;
	}
	
	var sameBattery = ($('batterytype').checked == lastBattery);
	
	
	
	
	if(batteryData && sameBattery){
		// we've already drawn this, so don't draw again.
		// however, resize if needed.
		$('eBatt').setStyle('width', size.x);
	 	$('eBatt').setStyle('height', size.y);
		return true;
	}
	
	// so we have something to look at whilst we wait...
	 $('eBatt').src="pleasewait.html";	 
	 $('eBatt').setStyle('width', size.x);
	 $('eBatt').setStyle('height', size.y);
	 
	
	lastBattery = $('batterytype').checked;
	
	var bPath = "";
	var chls = "";
	var chco = "";
	var chds = "";
	
	if ($('batterytype').checked) {
		bPath = chart.ForwardDist.slice(0, chart.bForwardErg.length - 1).join(',') + '|' + chart.bForwardErg.join(',');
		chls += '2';
		chco += '0000FF';
		chds += '0,' + chart.totDist + ',0,101';
		
		if (chart.bReverseErg.length > 0) {
			bPath += '|' + chart.ForwardDist.reverse().slice(0, chart.bReverseErg.length - 1).join(',') + '|' + chart.bReverseErg.join(',');
			chls += '|2';
			chco += ',0000FF';
			chds += ',0,' + chart.totDist + ',0,101';
			chart.ForwardDist.reverse()
		}
		
	}
	else {
	
		bPath = chart.ForwardDist.slice(0, chart.lForwardErg.length - 1).join(',') + '|' + chart.lForwardErg.join(',');
		chls += '2';
		chco += 'FF0000';
		chds += '0,' + chart.totDist + ',0,101';
		
		
		if (chart.lReverseErg.length > 0) {
			bPath += '|' + chart.ForwardDist.reverse().slice(0, chart.lReverseErg.length - 1).join(',') + '|' + chart.lReverseErg.join(',');
			chls += '|2';
			chco += ',FF0000';
			chds += ',0,' + chart.totDist + ',0,101';
			chart.ForwardDist.reverse()
		}
	}	

	batteryData = $H({
		'cht' : 'lxy',  // was lc
		'chs' : size.x+'x'+size.y,
		'chtt' : 'Battery Remaining',
		'chls' : chls,
		'chco' : chco,
		'chds'	: chds,
		'chxt' : 'x,x,y,y',
		'chxl'	: '1:|Kms|3:|Percent',
		'chxp' : '1,50|3,50',
		'chxs' : '0,676767,11.5,0,lt,676767|1,676767,11.5,0,lt,676767|2,676767,11.5,0,lt,676767|3,676767,11.5,0,lt,676767',
		'chxr'	: '0,0,'+chart.kmDist+'|2,0,100',
		'chd' : 't:'+bPath,
		'chg' : '3,10,2,6'   // the 3 at the start needs to be figured out.  it's the x distance.
	});
	
	
	//var chartURL = CHART_BASE_URL + '?' +chartData.toQueryString();
	//var cURL = chartURL.replace(/%2C/g , ',');
	//cURL = cURL.replace(/%2B/g , '+');

	 $('eBatt').src="chartloader.html?battery";	 
	 $('eBatt').setStyle('width', size.x);
	 $('eBatt').setStyle('height', size.y);
	
}
function showBattery( what, perc ){
		
		
		var Batt = $(what+'Batt');
		var BattPerc = $(what+'BattPerc');
		
		if( perc > 70){
			Batt.setStyle('background-image', 'url(imgs/thinuseagered.png)' );
			BattPerc.set('html', 'battery use <span class="txtRed">'+perc + '%</span>')			
		} else {
			Batt.setStyle('background-image', 'url(imgs/thinuseagegreen.png)' );
			BattPerc.set('html', 'battery use '+ perc + '%')
		}
		 
		if( perc < 0){
			perc = 0;
		} else if(perc > 100){
			perc = 100;
		}
		
		
		var pixels = -178 + ( perc * 1.57);
		
		Batt.setStyle('background-position', [pixels,0]);
	}

function clearMarkers(){

	while (markers.length){
		// clean out the old markers, cause we don't want them any more.
		var mrk = markers.pop();
		// cancel any event listeners for this marker...
		mrk.setMap(null);
	};
	// clear up old waypoints too...
	waypoints.each(function(wp){
		// cancel any event listeners for this marker...
		wp.setMap(null);
	});
}

function battPercent( energy, cap){
	// break it down into 5% chunks.
	
	var perc = Math.ceil( (energy/cap).round(2) *100 );
	var chunk = Math.floor(perc/5);
	if( perc%5 > 2){
		chunk ++;
	}
	
	return { 'chunk' : chunk * 5, 'act' : perc };
}
