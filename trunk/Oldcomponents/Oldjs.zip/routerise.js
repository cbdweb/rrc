// globals for Google Maps.
var directionDisplay;  			// 	the object for holding the map display.
var directionsService = null;   //	the object for managing the map requests. 
var map;						// the object to interact with the map.

// globals for storing/mapping routes.
var waypoints = [];
var markers = [];

// globals for breaking th path into smaller steps.
var maxSegment = 250;
var indexer = "lat={lat}&lng={lng}";
var simplePathData= null;
var geocoder = null;
var iconsize = null;
var anchor = null;
var origin = null;
var markerIcon = null;
var waypointIcon = null;

Number.prototype.toRad = function() {  // convert degrees to radians
	return this * Math.PI / 180;
};
function battPercent( energy, cap){
	// break it down into 5% chunks.
	
	var perc = Math.ceil( (energy/cap).round(2) *100 );
	var chunk = Math.floor(perc/5);
	if( perc%5 > 2){
		chunk ++;
	}
	
	return { 'chunk' : chunk * 5, 'act' : perc };
}
function addMarker(pt, markerno){

	var glatlng = new google.maps.LatLng(pt.lat,pt.lng);
	var marker = new google.maps.Marker({
	      position: glatlng, 
	      map: map, 
	      icon: markerIcon,
	      draggable : true,
	      flat : true,
	      clickable : true,
	      title : 'Drag to add a stop.'
	  }); 
	google.maps.event.addListener(marker, 'dragstart', function(){pickupMarker(marker);});
	google.maps.event.addListener(marker, 'drag', function(){moveMarker(marker);});
	// google.maps.event.addListener(marker, 'mouseup', function(event){dropMarker(event);});
	google.maps.event.addListener(marker, 'dragend', function(){dropMarker(marker);});
	marker.cbdPathIndex = markers.length;
	markers.push(marker);
	
}

function addWayPoint(id){
	// ok, here's the plan.
	// When they hit AddWaypoint, we add a new input at the bottom of $('waypoints').
	// we then get the location in the End input field, and copy it to the new input
	// and then we blank out the end point.
	/*
	var existingWP = wpd.getChildren('div');
	// dont let them keep adding blank ones.  they will have to enter in a value.
	if( existingWP.length){
		var lastwp = existingWP[existingWP.length-1];
		var inp = lastwp.getElement('input');
		if(inp.value == ""){
			return;
		}
	}
	*/
	var wpd = $('waypoints');
	var prevWP = $(id);
	// waypoints.splice(idNo, 0, null);
	
	drawWPHTML(wpd, prevWP, "");
	// calcRoute();
}

// load these functions when the DOM loads.
window.addEvent('domready', function(){
	
/*	$('addwaypoint').addEvent('click', function(e){
		e.stop();
		addWayPoint(e);
		// return false;
	});
*/	
	$('waypoints').addEvent('click', function(e){
		var btn = $(e.target);
		if(btn.get('tag') == "img"){
			btn = btn.getParent();
		}
		if(btn.hasClass('removeWaypoint')){
			e.stop();
			var theID = btn.getParent('div').id;
			removeWayPoint(theID);	
		}
		if(btn.hasClass('addWaypoint')){
			e.stop();
			var theID = btn.getParent('div').id;
			addWayPoint(theID);	
		}
		// return false;
	});
	var doReq = doRequest.pass([false]);
	$$('input[name=start]').addEvent('change', changeWaypoint);
	$$('input[name=end]').addEvent('change', changeWaypoint);
	$('weight').addEvent('change', doReq);
	$$('input[name=headwind]').addEvent('change', doReq);
	$$('input[name=routetype]').addEvent('change', calcRoute);
	$$('input[name=batterytype]').addEvent('change', doBatteries);
});



function initialize() {
	directionsService = new google.maps.DirectionsService();
	directionsDisplay = new google.maps.DirectionsRenderer();
	geocoder = new google.maps.Geocoder();
	// Initialize default values
	iconsize = new google.maps.Size(11,11,'px', 'px');
	anchor = new google.maps.Point(0,0);
	origin = new google.maps.Point(6,6);
	// markerIcon = new google.maps.MarkerImage('imgs/marker.gif', iconsize, anchor, origin);
	markerIcon = new google.maps.MarkerImage('http://maps.gstatic.com/intl/en_au/mapfiles/dd-via.png', iconsize, anchor, origin);
	
	// waypointIcon = new google.maps.MarkerImage('imgs/waypoint.gif', iconsize, anchor, origin);
	waypointIcon = new google.maps.MarkerImage('http://maps.gstatic.com/intl/en_au/mapfiles/dd-via.png', iconsize, anchor, origin);
	var zoom = 3;
	
	if (!navigator.geolocation) {
		ipBaseMap();
			
	} else {
		// we've got geolocation awareness, so use the "current location"
				
		navigator.geolocation.getCurrentPosition( gpsBaseMap, ipBaseMap);
	}
}

function gpsBaseMap(position){
	
	latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
	var myOptions = {
			zoom: 18,
			center: latlng,
			mapTypeId: google.maps.MapTypeId.ROADMAP
			
		};
	if ($('wp_0').value !== "") {
		if (geocoder) {
			geocoder.geocode({
				'latLng': latlng
			}, function(results, status){
				if (status == google.maps.GeocoderStatus.OK) {
					// put the address into the From text field.
					$('wp_0').value = results[0].formatted_address;
				}
			});
		}
	}

	doBaseMap(myOptions);
}
function ipBaseMap(){
	// If ClientLocation was filled in by the loader, use that info instead
	var latlng = new google.maps.LatLng(37.4419, -100.1419);
	if (google.loader.ClientLocation) {
		zoom = 13;
		latlng = new google.maps.LatLng(google.loader.ClientLocation.latitude, google.loader.ClientLocation.longitude);

	}
	var myOptions = {
		zoom: zoom,
		center: latlng,
		mapTypeId: google.maps.MapTypeId.ROADMAP
		
	};
	doBaseMap(myOptions);
}

function doBaseMap( myOptions ){
	map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
	directionsDisplay.setMap(map);
	
	calcRoute();  // calcroute now checks to see if it has a route, and if not, dosen't do anything.
	
}

function getFormattedLocation() {
	if (google.loader.ClientLocation.address.country_code == "US" &&
			google.loader.ClientLocation.address.region) {
		return google.loader.ClientLocation.address.city + ", " 
		+ google.loader.ClientLocation.address.region.toUpperCase();
	} else {
		return  google.loader.ClientLocation.address.city + ", "
		+ google.loader.ClientLocation.address.country_code;
	}
}
var indexer = "lat={lat}&lng={lng}";
var mapresults = null;
var pts = {};
var order = [];
var drawncount =0;
var maxAlt = 0;
var minAlt = 999999;
var totDist = 0;
var factDist = 0;



var lasttrip = null;
function doRequest(csv){
	if(!lasttrip){
		return false;
	}
	// clear out the last status messages...
	var summaryPanel = $('status');
	// summaryPanel.innerHTML = "";
	
	var weight = $('weight').get('value').toInt();
	var headwind = ($('headwind').checked == true);
	
	if(weight == 0){
		alert('Please select the weight of you and your bike and try again.');
		return false;
	}
	
	
	// summaryPanel.innerHTML +="<div id=\"progressarea\"><div id=\"progress\"></div><div style=\"border:1px solid #000; width:200px;\"><div id=\"progressbar\" style=\"width:1px;background:#000;\">&nbsp;</div></div></div>";
	
	var doGetMethod = lasttrip.collected || false;
	var disableThese = ['input', 'a', 'select'];
	var controlPanel = $('controlPanel');
	
	// var data = {'steps':calcPathSteps( lasttrip )};
	var data = simplePathData;
	
	var getArgs = "";
	if(doGetMethod){
		if(headwind != lasttrip.headwind){
			getArgs += '&headwind=' + headwind;
		}
		if(weight != lasttrip.weight){
			getArgs += '&weight=' + weight;
		}
	}
	
	lasttrip.headwind = headwind;
	lasttrip.weight = weight;
	
	
	data.headwind=headwind;
	data.weight=weight;
	data.makecsv=csv;

	// make a request to the get service, to initialise the Session.
	var req = new Request({
		'url' : '/RRC/routecalc',
		'noCache' : true,
		'method' : 'get',
		'async' : false
	});
	req.send();
	
	disableThese.each(function(elementtypes){
		var elements = controlPanel.getElements(elementtypes);
		elements.set('disabled', true);
		if(elementtypes=="a" ){
			elements.setStyle('display', 'none');
		}
	});
	var timedrequest = null;
	if(data.makecsv){
		// make an iframe, create a form, create a field, called data, with the json string in it. then submit the form to the servlet.
		// we should then be asked to save the file.... maybe.
		// the child document will get it's data value from this pages data field.
		
		
		var ifloader = $('iframeloader');
		ifloader.empty();
		
		// Ok, if we havent yet go this path, then we need to do the "post" approace,
		// otherwise, we can use the get approach.
		var iframeURL = doGetMethod ? '/RRC/routecalc?action=csv'+getArgs : 'getcsv.html';
		
		
		var iframe = new Element("iframe",{
			'src' : iframeURL
		});

		//var ifcontent = $(iframe.contentDocument.body);
		//var dfield = ifcontent.getElement('data');
		if( !doGetMethod){
			// becasue we're doing the post method, add the data field.
			var	 dfield = new Element("input",{
				'name' : 'data',
				'id' : 'data',
				'value' : JSON.encode(data) 
			});

			dfield.inject(ifloader,'bottom');
		}
		iframe.inject(ifloader,'bottom');
		// dfield.set('value', '{ "route" : '+JSON.encode(data) +'}');
	} else {
		
		var json = new Request.JSON({
			'url' : '/RRC/routecalc',
			'data' : { 'route' : JSON.encode(data) },
			'noCache' : false,
			'onSuccess' : function(json, txt){
				var results = $('battery');
				var bigbattery = 200;
				var littlebattery = 100;


				if(json){
					chart.alts = json.alts;
					drawChart();
					var lb = battPercent(json.totenergy.round(2) ,littlebattery);
					var lb2 = battPercent(json.totenergyRet.round(2) ,littlebattery);
					var bb = battPercent(json.totenergy.round(2) ,bigbattery);
					var bb2 = battPercent(json.totenergyRet.round(2) ,bigbattery);
					lastBattery = {
						'lb' : lb,
						'lb2' : lb2,
						'bb' : bb,
						'bb2' : bb2
					};
					
			
					doBatteries();			
			
					lasttrip.collected = true;
					
				} else {
					alert('Sorry, there was an error calculatin the path.');
				}
				// clean up the timed request...
				if(timedrequest){
					var results = $('progress');
					var bar = $('progressbar');
					// results.set('html', 'Completed.');
					// bar.setStyle('width', 200);
					timedrequest.stopTimer();
					disableThese.each(function(elementtypes){
						var elements = controlPanel.getElements(elementtypes);
						elements.set('disabled', false);
						if(elementtypes=="a" ){
							elements.setStyle('display', '');
						}
					});
				}
			}
		});

		
		
		if(doGetMethod){
			json.options.url = '/RRC/routecalc?action=json'+getArgs;
			json.options.method = 'get';
			json.options.data = '';
			
		}
		json.send();


		
	}
	timedrequest= new Request.JSON({
	    method: 'get',
	    'url' : '/RRC/routecalc',
		'noCache' : true,
		'onSuccess' : function(json, txt){
			
			//var results = $('progress');
			//var bar = $('progressbar');
			if(json){
				if(json.status=="Calculating" || json.status=="Collected"){
					var comp = Math.ceil(json.count / json.size *100);
					if( comp < 100){
						// draw the in progress bar.
						//results.set('html' , json.status + ' : ' + json.count + ' of ' + json.size + '('+comp+'%)');
						//bar.setStyle('width', comp * 2);
					} else {
						// results.set('html', 'Completed.');
						// bar.setStyle('width', 200);
						timedrequest.stopTimer();
						lasttrip.collected = true;
						disableThese.each(function(elementtypes){
							var elements = controlPanel.getElements(elementtypes);
							elements.set('disabled', false);
							if(elementtypes=="a" ){
								elements.setStyle('display', '');
							}
						});
					}
				} else {
					// results.set('html' , json.status);
					// bar.setStyle('width', 0);	
				}
			} else {
				// results.set('html' , txt);
				// bar.setStyle('width', 0);
			}
			
		},
	    initialDelay: 1000, 
	    delay: 1000,
	    limit: 15000
	}).startTimer();
	// timedrequest.send();
	return false;
	// and that's it, out marker is now included in the waypoints.
}

var lastBattery = null;
function doBatteries(){
	if ($('batterytype').checked) {
		showBattery('to', lastBattery.bb.chunk);
		showBattery('ret', lastBattery.bb2.chunk);
	} else {
		showBattery('to', lastBattery.lb.chunk);
		showBattery('ret', lastBattery.lb2.chunk);
	}
	
}
function showBattery( what, perc ){
		
		
		var Batt = $(what+'Batt');
		var BattPerc = $(what+'BattPerc');
		
		if( perc > 70){
			Batt.setStyle('background-image', 'url(imgs/thinuseagered.png)' );
			BattPerc.set('html', 'battery use <span class="txtRed">'+perc + '%</span>')			
		} else {
			Batt.setStyle('background-image', 'url(imgs/thinuseagegreen.png)' );
			BattPerc.set('html', 'battery use '+ perc + '%')
		}
		 
		if( perc < 0){
			perc = 0;
		} else if(perc > 100){
			perc = 100;
		}
		
		
		var pixels = -178 + ( perc * 1.57);
		
		Batt.setStyle('background-position', [pixels,0]);
	}

function clearMarkers(){

	while (markers.length){
		// clean out the old markers, cause we don't want them any more.
		var mrk = markers.pop();
		// cancel any event listeners for this marker...
		mrk.setMap(null);
	};
	// clear up old waypoints too...
	waypoints.each(function(wp){
		// cancel any event listeners for this marker...
		wp.setMap(null);
	});
}


function drawWaypointsHTML( trip ){

		var wpd = $('subPoints');
		// var newDiv = new Element('div');
		if(!trip){
			return;
		}
		wpd.empty();
		
		trip.routes.each( function( route, index ){
			// each route starts with its own waypoint.
			if( index == 0 ){
				// set the first waypoint...
				var wp0 = $('waypoint_0').getElement('input');
				wp0.set('value',route.start_geocode.formatted_address);
			} else {
				drawWPHTML(wpd, index, route.start_geocode.formatted_address  );
			}
		});
		// now add the end point.
				
		var lastRoute = trip.routes[ trip.routes.length-1];
		var wpEnd = $('waypoint_end').getElement('div');
		var wpEndInput = $('waypoint_end').getElement('input');
		wpEnd.set('id', 'waypoint_'+ trip.routes.length);
		wpEndInput.set('id', 'wp_'+ trip.routes.length);
		
		wpEndInput.set('value',lastRoute.end_geocode.formatted_address);
		// drawWPHTML(wpd, trip.routes.length, lastRoute.end_geocode.formatted_address , true );

}

function drawWPHTML(wpd, index, address, ending  ){
	// draw a single new waypoint.  used in a few places.
	
	var prevWP = null;
	if(typeof( index) == "object"){
		prevWP = index;
		index = 9999;
	}
	
	// '&nbsp;<a href="#" title="Remove Waypoint." class="removeWaypoint" >'+
	// '<img src="imgs/remove.gif" alt="Remove Waypoint" /></a>'+
	// '&nbsp;<a href="" title="Add Waypoint." class="addWaypoint">'+
	// '<img src="imgs/add.gif" alt="Add waypoint."/></a>'
	
	var newWaypoint = new Element('div', {
		'html' : '<input type="text" id="wp_'+index+'"/>',
		'id' : 'waypoint_'+ index,
		'class': 'hidden'
	});
	if( index ===0 || ending ){
		newWaypoint.removeClass('hidden');
	}
	// get rid of the last addWaypoint icon...
	if(prevWP){
		newWaypoint.inject(prevWP, 'after');
	} else {
		newWaypoint.inject(wpd, 'bottom');	
	}
	
	var wpinput = newWaypoint.getElement('input');
	wpinput.set('value', address);
	/*wpinput.addEvent('change', changeWaypoint);
	if(ending){
		var plus = newWaypoint.getElement('a.addWaypoint');
		if(plus){
			plus.addClass('hidden');
		}
	} */
}

function removeWayPoint(theID){
	var waypoint = $(theID);
	waypoint.dispose();
	var idNo = theID.replace('waypoint_', '').toInt();
	if(waypoints[idNo] ){
		waypoints.splice(idNo, 1);
	}
	timedrequest= new Request.JSON({
	    method: 'get',
	    'url' : '/RRC/routecalc',
		'noCache' : true,
		'onSuccess' : function(json, txt){
			
			var results = $('progress');
			var bar = $('progressbar');
			if(json){
				if(json.status=="Calculating" || json.status=="Collected"){
					var comp = Math.ceil(json.count / json.size *100);
					if( comp < 100){
						// draw the in progress bar.
						// results.set('html' , json.status + ' : ' + json.count + ' of ' + json.size + '('+comp+'%)');
						// bar.setStyle('width', comp * 2);
					} else {
						// results.set('html', 'Completed.');
						// bar.setStyle('width', 200);
						timedrequest.stopTimer();
						lasttrip.collected = true;
					}
				} else {
					// results.set('html' , json.status);
					// bar.setStyle('width', 0);	
				}
			} else {
				// results.set('html' , txt);
				// bar.setStyle('width', 0);
			}
			
		},
	    initialDelay: 1000, 
	    delay: 1000,
	    limit: 15000
	}).startTimer();
	
}
function latlngDist( pt1, pt2 ) {
	// returns the distance in meters
	if(!pt1){
		return 0;
	}
	var R = 6371; // km
	var dLat = (pt1.lat - pt2.lat).toRad();
	var dLon = (pt1.lng-pt2.lng).toRad();
	var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
	Math.cos(pt1.lat.toRad()) * Math.cos(pt2.lat.toRad()) *
	Math.sin(dLon/2) * Math.sin(dLon/2); 
	var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
	var d = R * c * 1000;
	return Math.ceil(d);
}

function simplifyPath( route ){
	var pts =  {};		// this is the structure to see if we already have a pt.
	var order = []; // the order collection of points.

	var steps = route.steps;
	steps.each( function( step ){
		var latlngs = step.lat_lngs;
		latlngs.each( function(pt){

			var cpt = {'lat' : pt.lat(), 'lng' : pt.lng()};
			var ind = indexer.substitute( cpt );
			if( !pts[ind] ){
				pts[ind] = true;
				order.push( cpt);
			}
		});
	});

	return order;
}

function calcPathSteps( trip ){
	var pts =  {};		// this is the structure to see if we already have a pt.
	var order = []; // the order collection of points.
	// ok, now that we have waypoints, a trip is made up of routes...
	var lastpt = null;
	// clean out the waypoints.
	clearMarkers();
	waypoints.empty();
	var mNo = 0;
	var routedist = 0;
	var routehalfway = 0;
	var droppedPt = false;
	var firstpt = true;
	trip.routes.each( function( route, rindex ){
		routedist = 0;
		routehalfway = route.distance.value /2;
		routehalfway = routehalfway - (routehalfway/10);
		
		droppedPt = false;
		var steps = route.steps;
		steps.each( function( step, sindex ){
			var latlngs = step.lat_lngs;
			latlngs.each( function(pt, index){
				if(rindex > 0 || sindex > 0){
					if( index == 0){
						// don't count the first point, cause it's the same as the last point of the one before
						return;
					}
				}	

				var cpt = {'lat' : pt.lat(), 'lng' : pt.lng()};
				var dist = latlngDist(lastpt, cpt);
				if( lastpt == null){
					lastpt = {};
					lastpt.lat = cpt.lat + 1 - 1;
					lastpt.lng = cpt.lng + 1 - 1;
				}

				var numsegments = Math.ceil(dist/maxSegment);
				
				var dff = 0;
				if(numsegments == 0){
					// to stop divide by zero...
					numsegments = 1;
					dff = 0;
				}
				var segdist = (dist/numsegments);
				var latdelta = (cpt.lat - lastpt.lat)/numsegments;
				var lngdelta = (cpt.lng - lastpt.lng)/numsegments;
				var tpt = {'lat' : lastpt.lat + 1 - 1, 'lng' : lastpt.lng + 1 - 1};
				
				for(var i = 0; i < numsegments-dff; i++){
					lastpt.lat = tpt.lat + 1 - 1;
					lastpt.lng = tpt.lng + 1 - 1;
					tpt = {};
					tpt.lat = lastpt.lat + latdelta;
					tpt.lng = lastpt.lng + lngdelta;
					var ind = indexer.substitute( tpt );
					//if( !pts[ind] ){
						pts[ind] = true;
						order.push( tpt);
						// each time we add a point, we need to add a marker.
						routedist += segdist;
						if(firstpt){
							addMarker(tpt, mNo);
							mNo ++;
							firstpt = false;
						}
						if(!droppedPt  && routedist >= (routehalfway)){
							droppedPt = true;
							addMarker(tpt, mNo);
							mNo ++;
						}
					//}
					lastpt.lat = tpt.lat + 1 - 1;
					lastpt.lng = tpt.lng + 1 - 1;
					
				}
			});
		});
		// ok, at the end of each "route", we effectively have a waypoint.
		// so add the last pt to our waypoint list...
		// these points already have the path index in them, that we'll need for making waypoints.
		// ok, keep the last pt too.
		addMarker(lastpt, mNo);
		mNo ++;
		firstpt = false;
		
		markers[markers.length-1].cbdIsWaypoint = true;
		markers[markers.length-1].setIcon(waypointIcon);
		markers[markers.length-1].setTitle(route.end_geocode.formatted_address);
		markers[markers.length-1].cbdAddress = route.end_geocode.formatted_address;
		waypoints.push(markers[markers.length-1]);
	
	});
	// now that we've done ALL the points we need, we can add the first marker to our waypoints list.
	// see http://www.w3schools.com/jsref/jsref_splice.asp for description of splice.
	markers[0].cbdIsWaypoint = true;
	markers[0].setIcon(waypointIcon);
	markers[0].cbdAddress = trip.routes[0].start_geocode.formatted_address;
	markers[0].setTitle(trip.routes[0].start_geocode.formatted_address);
	waypoints.splice(0, 0, markers[0] );
	// ok, now we have the order, I'm going to calculate the distances, even through we don't realy need to.
	var lastpt = null;
	order.each( function(pt){
		pt.dist = latlngDist(lastpt, pt);
		lastpt = pt;
	});
	
	// just to be sure we've got the right stuff, 
	
	
	// drawWaypointsHTML(  );
	
	
	return order;
}




var lastMoveTimer = 0;
function moveMarker(marker){
	if(marker){
		
		var latlng = marker.getPosition();
		// $('status').set('html', 'draged : '+latlng.lat() + ", " + latlng.lng() +" ->  " + marker.cbdPathIndex );
	} else {
		// $('status').set('html', 'draged');
	}
	// ok, re-work that path.
	/*
	var currentDate = new Date();
	var thisMoveTimer = currentDate.getTime();
	if( (thisMoveTimer - lastMoveTimer) > 1000){
		calcRoute(true);
		lastMoveTimer = thisMoveTimer;
	}
	*/
}

function dropMarker(marker){
	if(marker){
		var latlng = marker.getPosition();
		// $('status').set('html', 'drop : '+latlng.lat() + ", " + latlng.lng() +" ->  " + marker.cbdPathIndex );
	} else {
		// $('status').set('html', 'droped');
	}
	// ok, re-work that path.
	calcRoute();
}
function pickupMarker(marker){
	if(marker){
		var latlng = marker.getPosition();
		// $('status').set('html', 'picked up : '+latlng.lat() + ", " + latlng.lng() +" ->  " + marker.cbdPathIndex );
	} else {
		// $('status').set('html', 'picked up');
	}
	// here we need to add this point into the waypoints list.
	// using the cbdIsWaypoint and cbdPathIndex values stored in the marker, figure out where we need to add this waypoint in out list of waypoints.
	if(marker.cbdIsWaypoint){
		return true;
	}
	// ok, it's not yet a waypoint, so lets make it one.
	waypoints.some( function(wp, index){
		if( index == 0){
			return false;
		}
		var pwp = waypoints[index -1];
		if( (pwp.cbdPathIndex < marker.cbdPathIndex) &&  (marker.cbdPathIndex < wp.cbdPathIndex) ){
			// if out marker is between two existing waypoints, then we need to add out marker in here.
			waypoints.splice(index, 0, marker);
			marker.cbdIsWaypoint = true;
			marker.setIcon(waypointIcon);
			return true;
		}
		return false;
	});

	// and that's it, out marker is now included in the waypoints.
}

var nextWaypointID = 1;



function removeWayPoint(theID){
	var waypoint = $(theID);
	waypoint.dispose();
	var idNo = theID.replace('waypoint_', '').toInt();
	if(waypoints[idNo] ){
		waypoints[idNo].setMap(null);  // take the marker off the page.
		waypoints.splice(idNo, 1);
	}
	calcRoute();
}
/** 
 * Code for markers & waypoints.
 */


function changeWaypoint(event){
	var inp = event.target;
	//var parentdiv = inp.getParent('div');
	var parentdiv = inp.getParent();
	var theID = parentdiv.get('id');
	var tail = theID.replace('waypoint_', '');
	var idNo = tail.toInt();
	if (inp.value){
		geocoder.geocode( { 'address': inp.value}, function(results, status) {
		        if (status == google.maps.GeocoderStatus.OK) {
			          var marker = new google.maps.Marker({
			              map: map, 
			              position: results[0].geometry.location,
			              icon : waypointIcon
			          });
			          marker.cbdAddress = inp.value; 
			          // we've already got this waypoint, so just update it.
			          if(waypoints[idNo]){
			  			waypoints[idNo].setMap(null);  // remove this waypoint, cause we're making a new one.
			  		    waypoints[idNo] = marker;	
			  			} else {
			  			// ok, this waypoint ISNT here, so add it to the "end" of the waypoints.
			  			waypoints.push( marker );
   
			  		  }
			          calcRoute();
		        } else {
		        	alert("Geocode was not successful for the following reason: " + status);
		        }
		});
		
	}

}

function calcRoute( dragging) {
	var travelType = $('routetype').checked ? google.maps.DirectionsTravelMode.WALKING : google.maps.DirectionsTravelMode.DRIVING;
	var wps = [];
	var start = null;
	var end = null; 
	
	if(!waypoints.length){
		var wpd = $('waypoints');
		var existingwp = wpd.getElements('input[type=text]');
		
		
		existingwp.each( function(wp){
			var value = wp.get('value');
			if(value.trim() !==""){
				wps.push({'location':value, 'stopover' : true});
			}
		});
	} else {
		// ok, we have out waypoints array, so lets build up our wps list.
		waypoints.each( function(wp){
				wps.push({'location':(wp.cbdAddress||wp.getPosition()), 'stopover' : true});
		});
	}

	//Ok, we've got a full list of waypoints.  we need to get the first and last ones 
	// into Start and end, and the rest are real waypoints.
	if( wps.length ){
		start = wps[0].location;
		wps.splice(0, 1);  // take out the first item in the list.
		end = wps.pop();
		if(end){
			end = end.location;
		}
	}
	
	if(start == null || end == null){
		return false;
	}
	
	var request = {
			origin: start, 
			destination: end,
			travelMode: travelType,
			region : 'au'
	};
	if(wps.length){
		request.waypoints = wps;
	}
	

	if(!dragging){
		clearMarkers();
	}
	directionsService.route(request, function(response, status) {
		if (status == google.maps.DirectionsStatus.OK) {
			directionsDisplay.setDirections(response);
			var trip = response.trips[0];
			lasttrip = trip;
			drawWaypointsHTML(trip);
			
			var summaryPanel = document.getElementById("directions_panel");
			// summaryPanel.innerHTML = "";
			// For each route, display summary information.
			var totalDist = 0;
			for (var i = 0; i < trip.routes.length; i++) {
				var tripSegment = i + 1;
				// summaryPanel.innerHTML += "<b>Trip Segment: " + tripSegment + "</b><br />";
				// summaryPanel.innerHTML += trip.routes[i].start_geocode.formatted_address + " to ";
				// summaryPanel.innerHTML += trip.routes[i].end_geocode.formatted_address + "<br />";
				// summaryPanel.innerHTML += trip.routes[i].distance.text + " ( "  + trip.routes[i].distance.value + " meters )<br /><br />";
				totalDist += trip.routes[i].distance.value;
			}
			
			summaryPanel.innerHTML = '<div> Total Distance : '+ Math.ceil( totalDist/100)/10+'km ( '+totalDist +' meters)</div>';
			if(totalDist < 300000){  // less than 200km
				simplePathData = {'steps':calcPathSteps( lasttrip )};
			} else {
				alert('Sorry, but this path is too long.  Please break your journey into smaller pieces.');
			}

		}

	});
	
}    
var chart = {
	alts : null
};
function drawChart(  ){
	if (! chart.alts){
		return false;
	}
	// alts should be an array of altitudes.
	// see http://code.google.com/apis/maps/documentation/elevation/#CreatingElevationCharts
	var CHART_BASE_URL = 'http://chart.apis.google.com/chart';
	var eGraph = $('eGraph');
	var size = eGraph.getSize();
	
	// find the max and min pts.
	var aMin = 999999;
	var aMax = -999999;
	
	chart.alts.each( function(a){
		if(a<aMin){
			aMin = a;
		}
		if(a > aMax){
			aMax = a;
		}
	});
	
	// ok, we've got the max and min heights.  lets figure out the padding factor;.
	// start by figuring out teh diference between the 2 .
	var aDif = aMax - aMin;
	
	var mag = 1;
	var check = aDif / 10;
	while (check > 1){
		// for every 10 we divide check by, we multiply mag by 10.
		check = check / 10;
		mag = mag * 10;
	}
	
	aMin = Math.round((aMin - mag )/mag) *mag;
	aMax = Math.round((aMax + mag )/mag) *mag;
	
	var tickDist = Math.round((100/(aMax / mag))*100)/100;
	
	// alert(size.x+'x'+size.y);

	var chartData = $H({
		'cht' : 'lc',
		'chs' : size.x+'x'+size.y,
		'chl' : 'Elevation+in+Meters',
		'chco' : 'blue',
		'chds'	: aMin+','+aMax,
		'chxt' : 'x,y',
		'chxr' : '1,'+aMin+','+aMax,
		'chd' : 't:'+chart.alts.join(','),
		'chg' : '0,'+tickDist
	});
	
	
	var chartURL = CHART_BASE_URL + '?' +chartData.toQueryString();
	var cURL = chartURL.replace(/%2C/g , ',');
	cURL = cURL.replace(/%2B/g , '+');
	
	// $('eGraph').set('src', cURL);
	eGraph.setStyle('background-image', 'url('+cURL+')' );
	
}





