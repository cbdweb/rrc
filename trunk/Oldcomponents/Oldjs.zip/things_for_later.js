/*
// Keep the details about the polyLine route that WE are drawing...
var routeSegs = [];
var basePolylineOpts = {
    strokeOpacity: 1.0,
    strokeWeight: 2,
	clickable : 'true',
	mouseover : plMouseOver
};
		var legs = response.routes[0].legs;
			var steps = legs[0].steps;
			var lastPt = new google.maps.LatLng( steps[0].start_location.lat(),steps[0].start_location.lng() );
			
			steps.each(function(step){
				
				var latlngs = step.lat_lngs;
				
				latlngs.each( function( latlng ){
				
					if (lastPt !== latlng) {
						var flightPlanCoordinates = [	//new google.maps.LatLng(37.772323, -122.214897),
						//new google.maps.LatLng(21.291982, -157.821856)//,
						//new google.maps.LatLng(-18.142599, 178.431),
						//new google.maps.LatLng(-27.46758, 153.027892)
						//new google.maps.LatLng( latlng.start_location.lat(),latlng.start_location.lng() ),
						//new google.maps.LatLng( latlng.end_location.lat(),latlng.end_location.lng() )
						//lastPt,
						//latlng
						new google.maps.LatLng( lastPt.lat(),lastPt.lng() ),
						new google.maps.LatLng( latlng.lat(),latlng.lng() )
						];
						var flightPath = new google.maps.Polyline({
							path: flightPlanCoordinates,
							// strokeColor: "#FF0000",
							strokeColor: random_color(),
							strokeOpacity: 1.0,
							strokeWeight: 2,
							clickable : true
						});
						
						google.maps.event.addListener(flightPath,"mouseover",
                            function(){ flightPath.setOptions({strokeColor: "#FF0000", strokeOpacity: .8});});
						google.maps.event.addListener(flightPath,"mouseout",
							function(){ flightPath.setOptions({strokeColor: "#000000", strokeOpacity: 1.0});}); 
						
						flightPath.setMap(map);
						lastPt = latlng;
					}				
				});
			
			});	

function plMouseOver( event ){
	
	var e = event;
	
}
*/
// @format (hex|rgb|null) : Format to return, default is integer
function random_color(format)
{
 var rint = Math.round(0xffffff * Math.random());
 format = (format || 'hex');
 switch(format)
 {
  case 'hex':
   return ('#0' + rint.toString(16)).replace(/^#0([0-9a-f]{6})$/i, '#$1');
  break;
  
  case 'rgb':
   return 'rgb(' + (rint >> 16) + ',' + (rint >> 8 & 255) + ',' + (rint & 255) + ')';
  break;
  
  default:
   return rint;
  break;
 }
}


var map_canvas;			// the Div that contains the map.
var oldPath = [];			// the path that we've previously drawn.

/* Might be a place to start with the draggable paths... */
function doBaseMap( myOptions ){
	map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
	directionsDisplay.setMap(map);
	google.maps.event.addListener( map, 'tilesloaded', doPathEvents );
	calcRoute();  // calcroute now checks to see if it has a route, and if not, dosen't do anything.
	


	
}

function doPathEvents(){
	oldPath.each( function(path){
		path.removeEvent('mouseover', overPath);
	});
	var paths = map_canvas.getElements('path');
	paths.each( function(path){
		$(path).set('stroke', '#ff0000');
		path.set('stroke-width', 10);
		path.addEvent('mouseover', overPath);
		path.addEvent('click', overPath);
	})
}

function overPath( event ){
	alert("over");
}

function clickPath( event ){
	alert("click")
}


