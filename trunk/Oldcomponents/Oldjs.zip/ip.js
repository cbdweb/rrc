window.addEvent('load', function(){
	hideURLBar();
	
	// get the browser to support "Orientation" changes;
	var supportsOrientationChange = "onorientationchange" in window,
    	orientationEvent = supportsOrientationChange ? "orientationchange" : "resize";

	window.addEventListener(orientationEvent, function() {
		updateOrientation();
	}, false);

});