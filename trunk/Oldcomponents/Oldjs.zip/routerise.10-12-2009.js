var directionDisplay;
  var directionsService = null;
  var map;
	var cv = null;
	var ctx = null;
	Number.prototype.toRad = function() {  // convert degrees to radians
  	return this * Math.PI / 180;
	}

  function initialize() {
  	directionsService = new google.maps.DirectionsService();
    directionsDisplay = new google.maps.DirectionsRenderer();
    cv = $('canvas');
    if(Browser.Engine.trident){
     	// G_vmlCanvasManager.initElement(cv);
     	cv.style.visibility = 'visible';
    } 
    if (cv.getContext) {  
      ctx = cv.getContext("2d"); 
      ctx.strokeStyle='#cc0000';
      ctx.lineWidth = 1;
      ctx.beginPath();
    } 
    
   // Initialize default values
    var zoom = 3;
    var latlng = new google.maps.LatLng(37.4419, -100.1419);
    var location = "Showing default location for map.";

    // If ClientLocation was filled in by the loader, use that info instead
    if (google.loader.ClientLocation) {
      zoom = 13;
      latlng = new google.maps.LatLng(google.loader.ClientLocation.latitude, google.loader.ClientLocation.longitude);
      location = "Showing IP-based location: <b>" + getFormattedLocation() + "</b>";
    }

    var myOptions = {
      zoom: zoom,
      center: latlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }

    map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    directionsDisplay.setMap(map);
  }
  
   function getFormattedLocation() {
    if (google.loader.ClientLocation.address.country_code == "US" &&
      google.loader.ClientLocation.address.region) {
      return google.loader.ClientLocation.address.city + ", " 
          + google.loader.ClientLocation.address.region.toUpperCase();
    } else {
      return  google.loader.ClientLocation.address.city + ", "
          + google.loader.ClientLocation.address.country_code;
    }
  }
	var altURL = "http://ws.geonames.org/astergdemJSON?lat={lat}&lng={lng}&callback=addAlt";
	var indexer = "lat={lat}&lng={lng}";
	var mapresults = null;
	var pts = {};
	var order = [];
	var drawncount =0;
	var maxAlt = 0;
  var minAlt = 999999;
  var totDist = 0;
  var factDist = 0;
  
	function getAlts(route){
		  mapresults = $('map_results');
		  mapresults.set('innerHTML', '');
		  drawncount = 0;
		  maxAlt = 0;
		  minAlt = 999999;
		  order = [];
		  pts = {};
		  totDist = route.distance.value;
		  if(totDist > 0){
		  	factDist = cv.width / totDist;
		  }
			var steps = route.steps;
			steps.each( function( step ){
				var latlngs = step.lat_lngs;
				latlngs.each( function(pt){
					
					var ind = indexer.substitute( {'lat' : pt.lat(), 'lng' : pt.lng()} );
					if( !pts[ind] ){
						pts[ind] = {'pos' : order.length};
						order.push( ind );
						var url = altURL.substitute( {'lat' : pt.lat(), 'lng' : pt.lng()} );
						var req = new Request.JSONP({
							'url' : url						
						});
						req.send();
					}
				});
			});
		if(! mapresults){
			mapresults = $('map_results');
		}
		// addPt({"astergdem":192,"lng":10.2,"lat":50.01});
		var span = new Element('span',{'html' : '<br /> There are '+order.length+' points in this path' });
		span.inject( mapresults, 'bottom');	
	}


	
	function addAlt( pt ){
		var ind = indexer.substitute( {'lat' : pt.lat, 'lng' : pt.lng} );
		// this is the IMPORTANT LINE
		pts[ind] = $extend(pts[ind], pt);
		
		if( pt.astergdem  > maxAlt ){
			maxAlt = pt.astergdem;
		}
		if( pt.astergdem  < minAlt ){
			minAlt = pt.astergdem;
		}
		// this is a clear.  crazy as it sounds.
		cv.width = cv.width;
		if(!Browser.Engine.trident){
			ctx.font = "20px Arial";  
	   	ctx.fillStyle = "Blue";  
	    ctx.fillText("Please wait, analysing route...", 5, 30);  
	    
	 		ctx.font = "12px Arial";  
	   	ctx.fillStyle = "Black";  
	    ctx.fillText("Min Altitude :" + minAlt + "m, Max Altitude :" + maxAlt + "m, Rise : " + (maxAlt - minAlt)+"m", 5, 50);  
		}
		drawncount ++;
		if( drawncount == order.length ){
			drawGraph();
		}
	}
  
  function drawGraph(){
  	var factAlt = Math.ceil( cv.height-5 / (maxAlt - minAlt) ); 
  	var ptOffset = 0;
  	lastpt = null;
  	order.each(function(ind){
  		pt = pts[ind];
  		var ptAlt = ( pt.astergdem - minAlt ) * factAlt + 5;
  		if( !lastpt  ){
  			// ok, we're starting the line.  woo hoo.
  			ctx.moveTo( 0 , ptAlt );
  		} else {
  			var dist = latlonDist2( lastpt, pt);
  			ptOffset += Math.ceil(dist * factDist);
  		}
  		lastpt = pt;
  	});
  	
  	return true;
  		var ind = indexer.substitute( {'lat' : pt.lat, 'lng' : pt.lng} );
  	if( ctx){
      // ctx.moveTo( pts[ind].pos * 2, 150);
      if( drawncount == 0){
      	ctx.moveTo( pts[ind].pos *2 , 150-pt.astergdem );
      }
      ctx.lineTo( pts[ind].pos *2 +1, 150-pt.astergdem );
		}
		ctx.stroke();
  }
  
  function latlonDist( pt1, pt2 ) {
  	// returns the distance in meters
  	var R = 6371; // km
  	var dLat = (pt1.lat() - pt2.lat()).toRad();
		var dLon = (pt1.lng()-pt2.lng()).toRad();
			var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
			Math.cos(pt1.lat().toRad()) * Math.cos(pt2.lat().toRad()) *
			Math.sin(dLon/2) * Math.sin(dLon/2); 
		var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
		var d = R * c * 1000;
		return Math.ceil(d);
  }
  
  function latlonDist2( pt1, pt2 ) {
	  	// returns the distance in meters
	  	var R = 6371; // km
	  	var dLat = (pt1.lat - pt2.lat).toRad();
			var dLon = (pt1.lng-pt2.lng).toRad();
				var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
				Math.cos(pt1.lat.toRad()) * Math.cos(pt2.lat.toRad()) *
				Math.sin(dLon/2) * Math.sin(dLon/2); 
			var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
			var d = R * c * 1000;
			return Math.ceil(d);
	  }
  
  function calcRoute(csv) {
    var start = document.getElementById("start").value;
    var end = document.getElementById("end").value;
   
    var request = {
        origin: start, 
        destination: end,
        travelMode: google.maps.DirectionsTravelMode.DRIVING
    };
    directionsService.route(request, function(response, status) {
      if (status == google.maps.DirectionsStatus.OK) {
        directionsDisplay.setDirections(response);
        var trip = response.trips[0];
        var summaryPanel = document.getElementById("directions_panel");
        summaryPanel.innerHTML = "";
        // For each route, display summary information.
        for (var i = 0; i < trip.routes.length; i++) {
          var tripSegment = i + 1;
          summaryPanel.innerHTML += "<b>Trip Segment: " + tripSegment + "</b><br />";
          summaryPanel.innerHTML += trip.routes[i].start_geocode.formatted_address + " to ";
          summaryPanel.innerHTML += trip.routes[i].end_geocode.formatted_address + "<br />";
          summaryPanel.innerHTML += trip.routes[i].distance.text + "<br /><br />";
        }
        var pt1 = trip.routes[0].start_geocode.geometry.location;
        var pt2 = trip.routes[0].end_geocode.geometry.location;
        // summaryPanel.innerHTML += "trip dist (crow flies) = " + latlonDist( pt1, pt2 ) + " meters";
        // getAlts(trip.routes[0])
        var data = {'steps':simplifyPath( trip.routes[0] )};
        data.headwind=false;
        data.weight=75;
        data.makecsv=csv;
        
        if(data.makecsv){
        	// make an iframe, create a form, create a field, called data, with the json string in it. then submit the form to the servlet.
        	// we should then be asked to save the file.... maybe.
        	// the child document will get it's data value from this pages data field.
        	var ifloader = $('iframeloader');
        	ifloader.empty();
        	var iframe = new Element("iframe",{
        		'src' : 'getcsv.html'
        	});
        	
        	//var ifcontent = $(iframe.contentDocument.body);
        	//var dfield = ifcontent.getElement('data');
        	var dfield = new Element("input",{
        		'name' : 'data',
        		'id' : 'data',
        		'value' : JSON.encode(data) 
        	});
        	
        	dfield.inject(ifloader,'bottom');
        	iframe.inject(ifloader,'bottom');
        	// dfield.set('value', '{ "route" : '+JSON.encode(data) +'}');
        } else {
	        var json = new Request.JSON({
	        	'url' : '/RouteRiseCalculator/routecalc',
	        	'data' : { 'route' : JSON.encode(data) },
	        	'noCache' : false,
	        	'onSuccess' : function(json, txt){
	        		var results = $('directions_panel');
	        		if(json){
	        			var stats = new Element('div', {
	        				'html' :'<div>Energy : ' + json.totenergy.round(2) +' Watt Hours</div>' + 
	        						'<div>Distance : ' + json.totdist.round(2) +' meters</div>' +
	        						'<div>Est. time : ' + json.tottime.round(2) +' hours</div>' 
	        			})
	        			stats.inject(results, 'bottom');
	        		} else {
	        			alert('Sorry, there was an error calculatin the path.');
	        		}
	        	}
	        });
	        
	        json.send();
        }
      }
  
    });
  }    
  
  function simplifyPath( route ){
	 var pts =  {};		// this is the structure to see if we already have a pt.
	 var order = []; // the order collection of points.
	 
	 var steps = route.steps;
		steps.each( function( step ){
			var latlngs = step.lat_lngs;
			latlngs.each( function(pt){
				
				var cpt = {'lat' : pt.lat(), 'lng' : pt.lng()};
				var ind = indexer.substitute( cpt );
				if( !pts[ind] ){
					pts[ind] = true;
					order.push( cpt);
				}
			});
		});
	 
	return order;
  }